#!/usr/bin/python
#!/usr/bin/env python

from itertools import islice

import sys
import shlex
import cgi
import os
import time
print "Content-Type: text/plain;charset=utf-8\n"

print """<html>
<head>
<style>
button.accordion {
	background-color: #eee;
	color: #444;
	cursor: pointer;
	padding: 18px;
	width: 100%;
	border: none;
	text-align: left;
	outline: none;
	font-size: 15px;
	transition: 0.4s;
}

button.accordion.active, button.accordion:hover {
	background-color: #ddd;
}

button.accordion:after {
	content: '+';
	font-size: 13px;
	color: #777;
	float: right;
	margin-left: 5px;
}

button.accordion.active:after {
	content: "-"}


div.panel {
	padding: 0 18px;
	background-color: white;
	max-height: 0;
	overflow: hidden;
	transition: 0.6s ease-in-out;
	opacity: 0;
}

div.panel.show {
	opacity: 1;
	max-height: 500px;
}
</style>
</head>"""

form = cgi.FieldStorage()
side=form.getvalue("side")
side=str(side)
side=side.upper()
text=form.getvalue("text")
text=str(text)
text=text.replace('^','/')

type=form.getvalue("type")
type=str(type)
path=form.getvalue("id")
path=str(path)
page=form.getvalue("page")
page1=page[0]
page1=int(page1);
file = "tmp/"+path+"/"+side+"/sw_techsupportinfo";
text1='`show interface`'

if os.path.exists(file):
	#path = form.getvalue("path") // get path from harsh
	#command = raw_input("Enter command name: ");
	fp = open(file,"r");
	print'<button class="accordion">Interface</button>'
        print '<div class="panel">'
	for line in fp:
			if text1 in line:
					count=0
					line = line.rstrip('\n');
					for line in fp:
							if line.startswith('`show'):
									break;
							if count==1:
							   break
							if text.startswith('Eth'):
							   if len(text)==6:
								   text2=text[-3:]
							   elif len(text)==7:
								   text2=text[-4:]
							   elif len(text)==8:
								   text2=text[-5:]
							   elif len(text)==9:
								   text2=text[-6:]
							   text3="Ethernet"+text2+" "
							   """
							   if text3 in line:
								 print '<div class="panel">'
								 print line
							   """
			                                   for line in fp:
							        if line== '\n':
							             count=1;
				          		             break;
								print line.rstrip('\n')
						           print'</div>'
							elif text.startswith('Po'):
								   text2=text[-4:]
								   text3="port-channel"+text2

								   if text3 in line:
										 print '<div class="panel">'
										 print line
										 for line in fp:
											   if line== '\n':
												  break;
											   print line.rstrip('\n')
										 print '</div>'
							elif text.startswith('Veth'):
								   text2=text[-4:]
								   text3="Vethernet"+text2
								   if text3 in line:
										 print '<div class="panel">'
										 print line
										 for line in fp:
											   if line== '\n':
												   break;
											   print line.rstrip('\n')
										 print '</div>'
        print "</div>"
	fp.close();

	fp=open(file,"r");
	text5=text+"(P)"
	sumo=0
	print '<button class="accordion">Port-Channel Summary</button>'
	for line in fp:
		   text4='`show port-channel summary`'
		   if text4 in line:
				line =line.rstrip('\n');
				print'<div class="panel">'
				for line in fp:
					 if line.startswith('`show'):
						   break;
					 if text.startswith('Eth'):
							if text5 in line:
								print line
					 elif text.startswith('Po'):
						text5= text+"(SU)"
						if text5 in line:
							   print line
							   sumo=1
	if sumo==0:
		  print "no content found"
	print '</div>'
	fp.close();

	fp=open(file,"r");
	print"<button class='accordion'>LLDP NEIGHBOR</button>"
	for line in fp:
		   text4='`show lldp neighbors`'
		   if text4 in line :
				print ' <div class="panel">'
				line =line.rstrip('\n');
				for line in fp:
					 if line.startswith('Device ID'):
						print line
					 if line.startswith('`show'):
						   break;
					 if text.startswith('Eth') or text.startswith( 'Veth'):
							if text in line:
								print line
	print'</div>'

	fp=open(file,"r");

	print"<button class='accordion'>CDP NEIGHBORS</button>"
	for line in fp:
		   text4='`show cdp neighbors`'
		   if text4 in line :
				line =line.rstrip('\n');
				print '<div class="panel">'
				for line in fp:
					 if line.startswith('Device-ID'):
						print line
					 if line.startswith('`show'):
						   break;
					 if text.startswith('Eth') or text.startswith( 'Veth'):
							if text in line:
								print line
	print '</div>'
	fp.close();

	sumi=0
	fp=open(file,"r");
	print"<button class='accordion'>SYSTEM INTERNAL EVENT-HISTORY</button> "
	for line in fp:
		   text10='`show system internal ethpm event-history ethernet-all last 100'
		   if text10 in line:
				sumi=1
				print '<div class="panel">'
				line =line.rstrip('\n');
				for line in fp:
					 line=line.replace("<"," " )
					 line=line.replace(">"," ")
					 if line.startswith('`show'):
						   break;
					 if text.startswith('Eth'):
						   if len(text)==6:
								   text2=text[-3:]
						   else:
								   text2=text[-4:]
						   text3="Ethernet"+text2+" "
						   if text3 in line:
										 num= line[27:30]
										 num=str(num)
										 num=num.strip(" ")
										 print line
										 for line in fp:
											   if line.startswith(num):
												  break;
							                                   print line.rstrip('\n')
									                   break;
				print '</div>'
	if sumi==0:
		 print '<div class="panel">'
		 print "Command not found"
		 print'</div>'
	fp.close();

	fp=open(file,"r");
	print"<button class='accordion'> VLAN</button>"
	list=[]
	text9=text+","
	print"<div class='panel'>"
	for line in fp:
		   text4='`show vlan`'
		   if text4 in line:
				line =line.rstrip('\n');
				for line in fp:
					 if line.startswith('`show'):
						   break;
					 if text.startswith('Eth') or text.startswith('Veth'):
							if line[0]!= " ":
							   start=line[0:3]
							if text9 in line:
								 list.append(start)
				print list
	print"</div>"
	fp.close();

	fp=open(file,"r");
	print"<button class='accordion'>MAC-ADDRESS</button>"
	for line in fp:
		   text4='`show mac address-table`'
		   if text4 in line:
				line =line.rstrip('\n');
				print '<div class="panel">'
				for line in fp:
					 if "VLAN" in line:
						print line
					 if line.startswith('`show'):
						   break;
					 if text.startswith('Eth') or text.startswith('Veth'):
							if text in line:
								print line
				print'</div>'

	fp.close();

	fp=open(file,"r");
	texta=text+" "
	textb=text+":"
	print"<button class='accordion'>PLATFORM FWM INFO LIF ALL VERBOSE</button>"
	for line in fp:
		   text4='`show platform fwm info lif all verbose`'
		   if text4 in line :
				line =line.rstrip('\n');
				print'<div class="panel">'
				for line in fp:
					 if line.startswith('Device-ID'):
						print line
					 if line.startswith('`show'):
						   break;
					 if texta in line or  textb in line:
								print line
				print'</div>'
	fp.close();

	fp=open(file,"r");
	texta=text+" "
	print"<button class='accordion'>PINNING SERVER INTERFACE</button>"
	for line in fp:
		   text4='`show pinning server-interfaces`'
		   if text4 in line :
				line =line.rstrip('\n');
				print'<div class="panel">'
				for line in fp:
					 if line.startswith('SIF'):
						print line
					 if line.startswith('`show'):
						   break;
					 if  line.startswith(texta) :
								print line
				print'</div>'
	fp.close();
