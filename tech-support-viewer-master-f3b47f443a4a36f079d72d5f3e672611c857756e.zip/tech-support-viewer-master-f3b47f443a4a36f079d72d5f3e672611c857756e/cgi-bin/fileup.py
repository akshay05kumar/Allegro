#!/usr/bin/python
#!/usr/bin/env python
#print "Content-Type: text/plain;charset=utf-8\n" 
import cgi 
import os
import sys
import pprint
import shutil
import cgitb
import random
#import YourFormProcessor

from property import url 
form = cgi.FieldStorage() 
file1=form['file'];
upload_dir="/ws/sukatara-sjc/myfile" 
fout=open(upload_dir,"w");
fout.write(file1.file.read());
"""redirectURL = "index.html"

print 'Content-Type: text/html'
print 'Location: %s' % redirectURL
print # HTTP says you have to have a blank line between headers and content
print '<html>'
print '  <head>'
#print '    <meta http-equiv="refresh" content="0;url=%s" />' % redirectURL
print '    <title>You are going to be redirected</title>'
print '  </head>' 
print '  <body>'
print '    Redirecting... <a href="%s">Click here if you are not redirected</a>' % redirectURL
print '  </body>'
print '</html>'
"""
