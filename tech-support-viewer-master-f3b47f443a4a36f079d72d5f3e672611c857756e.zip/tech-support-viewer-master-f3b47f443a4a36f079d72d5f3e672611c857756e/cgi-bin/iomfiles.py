#!/usr/bin/python
#!/usr/bin/env python
import os
import cgi
import sys
import shlex
import datetime
import time

print "Content-Type: text/plain;charset=utf-8\n"
form = cgi.FieldStorage()
path = form.getvalue("id")
count = 0
directory = "tmp/"+path

for file in os.listdir(directory):
	if file.find("MEZZ") != -1 and file.endswith(".done")== 0 :
		print file
		count = count+1
if count == 0 :
	print "No Files found"
