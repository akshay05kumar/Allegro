#!/usr/bin/python
#!/usr/bin/env python

from itertools import islice
from property import url

import sys
import shlex
import cgi
import os
import time
import datetime

print "Content-Type: text/plain;charset=utf-8\n"

print"""<html>
<head>
<style>
button.accordion {
    background-color: #eee;
    color: #444;
    cursor: pointer;
    padding: 18px;
    width: 100%;
    border: none;
    text-align: left;
    outline: none;
    font-size: 15px;
    transition: 0.4s;
}
button.accordion.active, button.accordion:hover {
    background-color: #ddd;
}
button.accordion:after {
    content: '+';
    color: #777;
    font-weight: bold;
    float: right;
    margin-left: 5px;
}
button.accordion.active:after {
    content: '-';
}
div.panel {
    padding: 0 18px;
    background-color: white;
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.2s ease-out;
}
div.panel.show {
        opacity: 1;
        max-height: 500px;
}
.btn-group .button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px; 
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    float: left; 
    cursor: pointer;
    width: 24%;
}
.btn-group .button2 {
    background-color: #F44336;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    float: left;
    cursor: pointer;
    width: 24%;
}
</style>
</head>
<body>"""


form = cgi.FieldStorage()
path=form.getvalue("id")
iom_path = form.getvalue("id2")
sum=form.getvalue("count")
veth_name_p = form.getvalue("title")

veth_name = veth_name_p.split('-')[0]
status = ""

if 'up' in veth_name_p:
	status = "up"
else:
	status = "down"

side = ""
if 'A' in veth_name_p:
        side = "A"
elif 'B' in veth_name_p:
        side = "B"


# Untar MEZ files, create AA (if not created dynamically on clicking on mezzfilename)
# for vnic.cfg and debugdump data
t_file = "tmp/"+iom_path

if os.path.exists(t_file):
	
        result=os.listdir(t_file)
        for i in result:
		if i.startswith('MEZZ') and not i.endswith('done'):
			tarfile = i
			newpath = str(tarfile)
			newpath = newpath.split(".")[0]
			t_file = "tmp/"+iom_path+tarfile
			
			if os.path.exists("tmp/"+iom_path+"/AA"):
				os.system("cd tmp/"+iom_path+"/AA; tar -xzvf ../"+tarfile +" > /dev/null")
		
			elif os.path.isfile(t_file):
			        os.system("cd tmp/"+iom_path+"; mkdir AA; cd AA; tar -xzvf ../"+tarfile +" > /dev/null")
			        

# listing vnic.cfg and debugdump from all MEZZ files
vnic = []
debug = []
mezfile = "tmp/" +iom_path + "/AA";

if os.path.exists(mezfile):
        f = []
        for (dir, _, files) in os.walk(mezfile):
                for f in files:
                        paths = os.path.join(dir, f)
                        if os.path.exists(paths):
                                i =  paths.split('/AA/')[1]
				if i.endswith('vnic.cfg'):
					vnic.append(i)
				if i.endswith('debugdump'):
					debug.append(i)
#commands
text1 = "`show interface virtual status `"
text2 = "`show pinning border-interfaces`"
text3 = '`show port-channel summary`'
text4 = '`show lldp dcbx interface Ethernet'
text5 = '`show system internal dcbx info interface eth-all`'
text6 = '`show system internal vim event-hist int '
text7 = '`show lldp neighbors`'
text8 = '`show system internal vim info niv global`'
text9 = '`show interface brief`'

file = url+"/"+ path + "/"+side+"/sw_techsupportinfo";
                       
temp2="techsupport_detailed_iocard2"
temp3="techsupport_detailed_iocard1"
file2 = url+"/"+iom_path+"/B/"+temp2+"/"+"nxos"+"/show-tech-support-iom-nxos.out";
file3 = url+"/"+iom_path+"/A/"+temp3+"/"+"nxos"+"/show-tech-support-iom-nxos.out";
files = ""

if os.path.exists(file2):
         files = file2
elif os.path.exists(file3):
         files = file3
 

port_channel = []
bound_channel = []
bound = ""
pinned = ""
bound_summary = []
states_c = ""
if_index = "..if_index.."
server = "-"

#eth with their respective bound channel and channel id
if os.path.exists(file):
	#show interface virtual status
	fp = open(file,"r")
	for line in fp:
		if text1 in line or '`show interface virtual status`' in line:
			x = -1
			line = line.rstrip('\n');
                        for line in fp:
                        	if line.startswith('`show'):
                                	break;
                                line = line.replace("<", " ")
                                line = line.replace(">", " ")
				words = line.split()
				
				if veth_name in line:
					words = line.split()
					bound = words[2]
					channel = words[3]									
        fp.close();
else:
	print("NO FILE FOUND")

#Unique states for ideal veth (mamoth?)
prev_state_c = ['VIM_NIV_VIF_FSM_ST_INIT', 'VIM_NIV_VIF_FSM_ST_CREATED', 'VIM_NIV_VIF_FSM_ST_BOUND', 'VIM_NIV_VIF_FSM_ST_WAIT_ATTACH', 'VIM_NIV_VIF_FSM_ST_WAIT_BUP', 'VIM_NIV_VIF_FSM_ST_UP_ACTIVE']
event_c = ['VIM_NIV_VIF_FSM_EV_CREATED', 'VIM_NIV_VIF_FSM_EV_BOUND', 'VIM_NIV_VIF_FSM_EV_ATTACH', 'VIM_NIV_VIF_FSM_EV_BRING_UP', 'VIM_NIV_VIF_FSM_EV_SEND_BUP', 'VIM_NIV_VIF_FSM_EV_BUP_DONE_ACTIVE', 'VIM_NIV_VIF_FSM_EV_ADMIN_UP_ACTIVE', 'VIM_NIV_VIF_FSM_EV_SET_DONE', 'VIM_NIV_VIF_FSM_EV_STATS_CLEAR', 'VIM_NIV_VIF_FSM_EV_STATS_DONE']
next_state_c = ['VIM_NIV_VIF_FSM_ST_CREATED', 'VIM_NIV_VIF_FSM_ST_BOUND', 'VIM_NIV_VIF_FSM_ST_WAIT_ATTACH', 'VIM_NIV_VIF_FSM_ST_WAIT_BUP', 'VIM_NIV_VIF_FSM_ST_UP_ACTIVE']

#checking lldp states, check in dcbx convergence
lldp_functions_c = ['lldp_update_lc_online()','lldp_init_sat_info()','lldp_update_lc_online()','lldp_sat_intf()','dcx_if_set_lock()','dcx_if_set_lock()','lldp_send_intf_config()','lldp_sat_intf()','dcx_update_intf_online()','dcx_if_set_lock()','lldp_update_lc_online()','lldp_update_lc_online()']

veth_version = ""
#Version `show version `
if os.path.exists(file):
	fp = open(file, "r")
	for line in fp:
		if '`show version `' in line:
			for line in fp:
				if line.startswith('`show'):
					break
				if 'cisco UCS' in line:
					words= line.split(' ')
					veth_version = words[4]
	fp.close()

#Event-history
new_prev = []	#for unique states, to compare
new_event= []
new_next = []

eve = "Triggered event:"
prev = "Previous state:"
next = "Next state:"
cur = "Curr state:"
vethernet = "Vethernet"+veth_name.split("h")[1]
c_state = ""
event_history_log = []
c_state2 = ""
text10 = '`show system internal vim event-history all `'
event_hist = 0
time_m = []
time_n = []
event_m = []
event_n = []
prev_state_m = []
prev_state_n = []
next_state_m = []
next_state_n = []

found = 0
if os.path.exists(file):
        text6 = text6+'veth '+veth_name.split('h')[1]+'`'	#if command is present for indidvidual veths
		
        fp = open(file, "r");
        for line in fp:
                if text6 in line:
			event_history_log.append('<h3><i>Data Fetched from : '+text6+'</i></h3>')
			m = -1
			n = -1
                        event_hist = 1
                        line = line.rstrip('\n');
                        for line in fp:
                                if line.startswith('`show'):
                                        break;
                                line = line.replace("<", " ")
                                line = line.replace(">", " ")
                                event_history_log.append(line.rstrip('\n'))
                                #Finding time
                                if "Transition" in line:
                                        words = line.split()
                                        for word in words:
                                                x = len(words)
                                                ts = words[x-5]+" "+words[x-4]+" "+words[x-3]+" "+words[x-2]+" "+ words[x-1]
						if 'usec' in word:
							usec = words[words.index(word)-1]         
                                        if found ==0:
                                        	if m>0 and not len(next_state_m) != m:
                                                	next_state_m.insert(m,'-NO ENTRY-')
                                                if m>0 and not len(prev_state_m) != m:
                                                        prev_state_m.insert(m,'-NO ENTRY-')
                                                if m>0 and not len(event_m) != m:
                                                        event_m.insert(m,'-NO ENTRY-')

                                                m = m +1
                                                time_m.insert(m, ts+' '+usec)
                                        else:
                                                if n>0 and not len(next_state_n) != n:
                                                	next_state_n.insert(n,'-NO ENTRY-')
                                                if n>0 and not len(prev_state_n) != n:
                                                        prev_state_n.insert(n,'-NO ENTRY-')
                                                if n>0 and not len(event_n) != n:
                                                        event_n.insert(n,'-NO ENTRY-')

                                                n = n+1
                                                time_n.insert(n, ts+' '+usec)

                                #Finding events
                                elif eve in line:
                                        words=line.split()
                                        for word in words:
                                                if "VIM" in word:
                                                        et=word.strip('[')
                                                        et=et.strip(']')
                                                        if found == 0:
                                                                event_m.insert(m,et)
                                                        else:
                                                                event_n.insert(n,et)
                                                                if et not in new_event:
                                                                        new_event.append(et)
                                #Finding previous state
                                elif prev in line:
                                        words= line.split()
                                        for word in words:
                                                if word.find("VIM") != -1:
                                                        st=word.strip('[')
                                                        st= st.strip(']')

                                                        if found == 0:
                                                                prev_state_m.insert(m,st)
                                                        else:
                                                                prev_state_n.insert(n,st)
                                                                if st not in new_prev:
                                                                        new_prev.append(st)


                                #finding next state
                                elif next in line:
                                        words = line.split()
                                        for word in words:
                                                if word.find("VIM") != -1 and found == 0:
                                                        nt = word.strip('[')
                                                        nt = nt.strip(']')
                                                        next_state_m.insert(m,nt)
                                                elif word.find("FSM") != -1 and found == 1:
                                                        nt = word.strip('[')
                                                        nt = nt.strip(']')
                                                        if 'FSM_ST_NO_CHANGE' in nt:
                                                                next_state_n.insert(n,prev_state_n[n])
                                                        else:
                                                                next_state_n.insert(n,nt)
                                                                if nt not in new_next:
                                                                        new_next.append(nt)
                                #current stat
                                if cur in line:
                                        words=line.split()
                                        for word in words:
                                                if word.find("VIM") != -1:
                                                        #print found
                                                        if found ==0:
                                                                c_state = word.strip('[')
                                                                c_state = c_state.strip(']')
                                                                found = 1
                                                        else:
                                                                c_state2 = word.strip('[')
                                                                c_state2 = c_state2.strip(']')
                                                                found  =0
        fp.close()
	
	#if individual event-history is not available. get event history from history all command
        fp = open(file,"r")
        if event_hist == 0:
                for line in fp:
                        if text10 in line:
				event_history_log.append('<h3><i>Data Fetched from : '+text10+'</i></h3>')
                                line = line.rstrip('\n');
                                for line in fp:
					m = -1
					n = -1
                                        if line.startswith('`show'):
                                                break;
                                        line = line.replace("<", " ")
                                        line = line.replace(">", " ")

                                        if vethernet in line:
                                                event_history_log.append(line.rstrip('\n'))
                                                for line in fp:
                                                        if line.startswith('`show'):
                                                                break
                                                        if len(c_state2) != 0:
                                                                break
							event_history_log.append(line.rstrip('\n'))
                                                        #Finding time
                                                        if "Transition" in line:
                                                                words = line.split()
                                                                for word in words:
                                                                        x = len(words)
                                                                        ts = words[x-5]+" "+words[x-4]+" "+words[x-3]+" "+words[x-2]+" "+ words[x-1]
	        		                                        if 'usec' in word:
		                	                                        usec = words[words.index(word)-1]

								if found ==0:
                                                                        if m>0 and not len(next_state_m) != m:
                                                                                next_state_m.insert(m,'-NO ENTRY-')
                                                                        if m>0 and not len(prev_state_m) != m:
                                                                                next_state_n.insert(n,'-NO ENTRY-')
                                                                        if m>0 and not len(event_m) != m:
                                                                                next_state_m.insert(m,'-NO ENTRY-')

									m = m +1
									time_m.insert(m, ts+' '+usec)
								else:
									if n>0 and not len(next_state_n) != n:
										next_state_n.insert(n,'-NO ENTRY-')
                                                                        if n>0 and not len(prev_state_n) != n:
                                                                                next_state_n.insert(n,'-NO ENTRY-')
                                                                        if n>0 and not len(event_n) != n:
                                                                                next_state_n.insert(n,'-NO ENTRY-')
  
									n = n+1
									time_n.insert(n, ts+' '+usec)


                                                        #Finding previous state
                                                        elif prev in line:
                                                                words= line.split()
                                                                for word in words:
                                                                        if word.find("VIM") != -1:
                                                                                st=word.strip('[')
                                                                                st= st.strip(']')
                                                                                if found ==0:
                                                                                        prev_state_m.insert(m,st)
                                                                                else:
                                                                                        prev_state_n.insert(n, st)
                                                                                        if st not in new_prev:
                                                                                                new_prev.append(st)


                                                        #Finding events
                                                        elif eve in line:
                                                                words=line.split()
                                                                for word in words:
                                                                        if "VIM" in word:
                                                                                et=word.strip('[')
                                                                                et=et.strip(']')
                                                                                if found == 0:   
											event_m.insert(m,et)
                                                                                else:
											event_n.insert(n, et)
											if et not in new_event:
												new_event.append(et)


                                                        #finding next state
                                                        elif next in line:
								
                                                                words = line.split()
                                                                for word in words:
                                                                        if word.find("VIM") != -1 and found == 0:
                                                                                nt = word.strip('[')
                                                                                nt = nt.strip(']')
										next_state_m.insert(m, nt)
                                                                        elif word.find("FSM") != -1 and found == 1:
										
                                                                                nt = word.strip('[')
                                                                                nt = nt.strip(']')
										
                                                                                if 'FSM_ST_NO_CHANGE' in nt:
											next_state_n.insert(n, prev_state_n[n])
                                                                                else:
											next_state_n.insert(n, nt)
											if nt not in new_next:
												new_next.append(nt)
										
                                                        #current state
                                                        if cur in line:
                                                                words=line.split()
                                                                for word in words:
                                                                        if word.find("VIM") != -1:
                                                                                if found ==0:
                                                                                        c_state = word.strip('[')
                                                                                        c_state = c_state.strip(']')
                                                                                        found = 1
                                                                                else:
                                                                                        c_state2 = word.strip('[')
                                                                                        c_state2 = c_state2.strip(']')
                                                                                        found = 0
        fp.close();

else:
        print("NO FILE FOUND")

#Findinf if_index of veth
if os.path.exists(file):
        #show interface snmp-ifindex
        fp = open(file,"r")
        for line in fp:
                if '`show interface snmp-ifindex`' in line:
                        line = line.rstrip('\n');
                        for line in fp:
                                if line.startswith('`show'):
                                        break;
                                line = line.replace("<", " ")
                                line = line.replace(">", " ")
                                words = line.split(" ")

                                if veth_name in line:
					words = line.split()
					for word in words:
						if veth_name in word:
							if_index = words[words.index(word)+2]
							if_index = if_index.strip('(')
							if_index = if_index.strip(')')
        fp.close();

#trace_logs
veth_log = []

#for large files, where vim_trace_log.1,2,3... exists
vim_trace_log = []
directory = url +"/"+path+"/"+side+"/sw_trace_logs"
#print directory
if os.path.exists(directory):
        result=os.listdir(directory)
        for l in result:
                if "vim_trace" in l:
			#f not (l.endswith("current") or l.endswith("initial")):
			vim_trace_log.append(l)
vim_trace_log.sort()
vim_trace_log.reverse()	#old ones have higher numbers
#For all logs
for ele in vim_trace_log:
	file_log = url+"/"+path+"/"+side+"/sw_trace_logs/"+ele
	if os.path.exists(file_log):
        	fp3= open(file_log,"r")
        	for line in fp3:
                	if veth_name in line:
        	                if '<h3><i>File name : sw_trace_logs/'+ele+'</i></h3>' not in veth_log:
	                                veth_log.append('<h3><i>File name : sw_trace_logs/'+ele+'</i></h3>')
                        	veth_log.append(line.rstrip('\n'))
		fp3.close()

#states check
if c_state2 == "VIM_NIV_VIF_FSM_ST_UP_ACTIVE":
	states_c = 'true'
else:
	states_c = 'false'

#server information
if os.path.exists(file):
        #show interface
        fp = open(file,"r")
        for line in fp:
                if '`show interface`' in line:
                        line = line.rstrip('\n');
                        for line in fp:
                                if line.startswith('`show'):
                                        break;
                                line = line.replace("<", " ")
                                line = line.replace(">", " ")
                                words = line.split(" ")

                                if 'Vethernet'+veth_name.split('h')[1] in line:
					for line in fp:
						if 'server' in line:
							words = line.split()
							for word in words:
								if 'server' in word:
									server = words[words.index(word)+1].strip(',')
							break
						if '`show' in line:
							break				
        fp.close();

#For each Veth
i=0
veth_status = []
lldp =[]
dcbx = []
channel = []
bound_channel_new = []
pinned = "-"
print "<h1>"+veth_name+"</h1>"
print 'Server : '+server
#print 'Veth Version : '+veth_version
print 'Bound interface : '+bound

fp = open(file,"r")
for line in fp:
	if text2 in line:
		line = line.rstrip('\n')
		for line in fp:
			if line.startswith('`show'):
                                break
                        line = line.replace("<", " ")
                        line = line.replace(">", " ")
                        words = line.split()
                        if 'Active' in line:
                                        pinned = words[0]
                        if veth_name in line:
                                        break
fp.close()
print "Pinned Interface : "+pinned

#bound interfaces port-channel
if  bound.startswith('P'):
	if os.path.exists(file):
                fp = open(file,"r")
                for line in fp:
                        if text3 in line:	#port channel summary
                                line = line.rstrip('\n')
                                for line in fp:
                                        if line.startswith('`show'):
                                                break;
                                        line = line.replace("<"," ")
                                        line = line.replace(">"," ")
                                        words = line.split(" ")
                                        for word in words:
                                                if word.split("(")[0] == bound:
                                                        words = line.split(" ")
                                                        for word in words:
                                                                if word.startswith('Eth') and len(word) > 3:
                                                                        bound_channel.append(word.split("(")[0])
		print "Bound interface-"+bound+" : ",
        	print bound_channel
		bound_channel_new = bound_channel
                fp.close()
	
	
#pinned interfaces port-channel
if  pinned.startswith('P'):
	if os.path.exists(file):
                fp = open(file,"r")
                for line in fp:
                        if text3 in line:	#port cchannel summary
                                line = line.rstrip('\n')
                                for line in fp:
                                        if line.startswith('`show'):
                                                break;
                                        line = line.replace("<"," ")
                                        line = line.replace(">"," ")
                                        words = line.split(" ")
                                        for word in words:
                                                if word.split("(")[0] == pinned:
                                                        words = line.split(" ")
                                                        for word in words:
                                                                if word.startswith('Eth') and len(word) > 3:
                                                                        port_channel.append(word.split("(")[0])
		
	        print "Pinned interface-"+pinned+" : ",
        	print port_channel
                fp.close()
                
#status down reason
if status == "down":
 s_count = 0
 if os.path.exists(file):
   fp = open(file, "r")
   for line in fp:
        if '`show interface brief`' in line:
                line = line.rstrip('\n')
                for line in fp:
                        if line.startswith('`show'):
                                break
                        line = line.replace("<", " ")
                        line = line.replace(">", " ")
                        words = line.split()
                        if veth_name in line:
				if s_count == 1:
					break
				s_count = 1
                                print '<h3>Veth Down : ',
                                words = line.split()
                                st = words.index('down')+1
                                for st in range(words.index('down')+1, words.index('auto')):
                                        print words[st],
                                print '</h3>'
                                

fp.close()



#lldp neighbors
if bound.startswith('P'):	#for port channel, find for all the eths, otherwise only bound interface
		j=0
		for j in range(len(bound_channel)):
			if os.path.exists(file):
				eth = bound_channel[j]+" "
				fp= open(file,"r")
				for line in fp:
					if text7 in line:	#show lldp neighbors
						line = line.rstrip('\n')
						for line in fp:
							if line.startswith('`show'):
								break
							if eth in line:
								lldp.append(line.rstrip('\n'))
				fp.close()
else:
		eth = bound
		if os.path.exists(file):
			fp = open(file,"r")
			for line in fp:
				if text7 in line:
					line = line.rstrip('\n')
					for line in fp:
						if line.startswith('`show'):
							break
						if eth in line:
							lldp.append(line.rstrip('\n'))
			fp.close()
#lldp end
		
#dcbx convergence 
if bound.startswith('P'):
		j=0
		for j in range(len(bound_channel)):
			if os.path.exists(file):
				eth = bound_channel[j]
				fp = open(file,"r")
				for line in fp:
					if text8 in line: 	#show system internal vim info niv global
						line= line.rstrip('\n')
						for line in fp:
							if line.startswith('`show'):
								break
							if line.rstrip('\n') == "Phy Info - "+eth:
								dcbx.append(line.rstrip('\n'))
								for line in fp:
									if "dcx_info.iov_on" in line:
										dcbx.append(line.rstrip('\n'))
										break
							
else:
		eth = bound
		if os.path.exists(file):
                        fp = open(file,"r")
                        for line in fp:
                        	if text8 in line:	#`show system internal vim info niv global`
                                	line= line.rstrip('\n')
                                        for line in fp:
                                        	if line.startswith('`show'):
                                                	break
                                                if line.rstrip('\n') == "Phy Info - "+eth:
							dcbx.append(line.rstrip('\n'))
                                                        for line in fp:
                                                        	if "dcx_info.iov_on" in line:
									dcbx.append(line.rstrip('\n'))
                                                                        break
			fp.close()
#dcbx end
		
#channel
if os.path.exists(file):
	fp = open(file,"r")
	for line in fp:
			if text8 in line:	#`show system internal vim info niv global`
				line= line.rstrip('\n')
				for line in fp:
					if line.startswith('`show'):
						break
					if "Phy Info" in line and bound in line:
                                        	channel.append(line.rstrip('\n'))
                                                for line in fp:
                                                	if "vic_info.vic_open_rcvd" in line or "vic_info.vic_open_acked" in line or "vic_info.vic_open_sent" in line:
                                                        	channel.append(line.rstrip('\n'))
                                                        if "Phy Info" in line:

                                                        	break
	fp.close()

#Vethxxx attached Interface details
veth_interface = []
if os.path.exists(file):
		fp = open(file,"r")
		for line in fp:
			if text8 in line:	#`show system internal vim info niv global`
				line = line.rstrip('\n')
				for line in fp:
					if line.startswith('`show'):
						break
					if "Interface "+veth_name in line:
						veth_interface.append(line.rstrip('\n'))
						for line in fp:
							if "Interface" in line:
								break
							if 'show' in line:
								break
							veth_interface.append(line.rstrip('\n'))
							
							
		fp.close()

#lldp_trace_log.initial
j=0
correct_count = 0
for j in range(len(bound_channel)):
                        eth_n = "Ethernet"+bound_channel[j].split('h')[1]
                        lc = 0
                        check_count = 0
                        lldp_log  = url+"/"+path+"/"+side+"/sw_trace_logs/lldp_trace_log.initial"
                        if os.path.exists(lldp_log):
                                fp = open(lldp_log,"r")
                                for line in fp:
                                        if eth_n+" s" in line:
                                                for line in fp:
                                                        if line.startswith('['):
                                                                if lldp_functions_c[lc] in line:
                                                                        check_count = check_count+1
                                                                lc = lc+1
                                                        if "Ethernet" in line:
                                                                break
                                if check_count == len(lldp_functions_c):
					correct_count = correct_count+1
                                fp.close()
	
#Progress Bar
print '<div class="btn-group">',
#LLDP status check
if (len(lldp) == len(bound_channel) and bound.startswith('P')) or (bound.startswith('E') and  len(lldp)==1):
	print '<button class="button">LLDP</button>',
else:
	print '<button class="button2">LLDP</button>',
#DCBX status check
yes_count = 0
for item in dcbx:
	if "yes" in item:
				yes_count = yes_count+1
if (yes_count == len(bound_channel) and bound.startswith('P')) or (bound.startswith('E') and yes_count == 1 ) and correct_count==len(bound_channel):
			print '<button class="button">DCBX</button>',
else:
			print '<button class="button2">DCBX</button>',
#Channel formation check
true_count = 0
for item in channel:
	if "true" in item:
		true_count = true_count+1
if true_count == 3:
	print '<button class="button">Channel Formation</button>',
else:
	print '<button class="button2">Channel Formation</button>',
#states check
if states_c == "true":
	print '<button class="button">States</button>',
else:
	print '<button class="button2">States</button>',

print '</div>'		
print '<p style="clear:both"><br></p>'


#Accordion
print "<button class='accordion'>LLDP Neighbors</button>"
print "<div class='panel'>"
print '<h3><i>Data Fetched from : `show lldp neighbors`</i></h3>'
print "Device ID            Local Intf      Hold-time  Capability  Port ID"
for item in lldp:
	print item
print "</div>"

print "<button class='accordion'>DCBX Convergence</button>"
print "<div class='panel'>"
print '<h3><i>Data Fetched from : `show system internal vim info niv global`</i></h3>'
for item in dcbx:
	print item
print "</div>"

print "<button class='accordion'>Channel Formation</button>"
print "<div class='panel'>"
print '<h3><i>Data Fetched from : `show system internal vim info niv global`</i></h3>'
for item in channel:
	print item
print "</div>"
		
if os.path.exists(files):
		bound_summary = []
		#bound data
		if bound.startswith('P'):
			#bound iom file				
                	j = 0
	                for j in range(len(bound_channel)):
				eth = bound_channel[j]
				fp = open(files,"r")
        	                for line in fp:
                	                if text5 in line:		#`show system internal dcbx info interface eth-all`
                        	                line = line.rstrip('\n')
                                	        for line in fp:
                                        	        if line.startswith('`show'):
                                                	        break
							if "Interface info for" in line and eth+')' in line:
								line = line.rstrip('\n')
								bound_summary.append(line)
								for line in fp:	
									if "Interface info for" in line and eth not in line:
										break
									if "show" in line:
										break
									bound_summary.append(line.rstrip('\n'))
	                        fp.close()
		else:
			eth = bound
                        if os.path.exists(file2):
				files = file2
                        elif os.path.exists(file3):
				files = file3                                
			fp = open(files,"r")
		        for line in fp:
        			if text5 in line:
                			line = line.rstrip('\n')
                        		for line in fp:
                                        	if line.startswith('`show'):
                                        		break
						if "Interface info for" in line and eth in line:
							line=line.rstrip('\n')
							bound_summary.append(line)
							for line in fp:
								if "Interface info for" in line and eth not in line:
									break
								bound_summary.append(line.rstrip('\n'))


	                	fp.close()
		
b = 0
x = 0
print "<button class ='accordion'>Bound Interface Summary</button>"
print '<div class="panel">'
#print 'Data Fetched from : `show system internal dcbx info interface eth-all`'
if bound_summary == []:
	print 'No data Found as no IOM file is present'
for b in range(len(bound_summary)):
			print '<h3><i>Data Fetched from : `show system internal dcbx info interface eth-all` (IOM)</i></h3>'
			ele= bound_summary[b]
			if "Interface info for" in ele or "type: 7" in ele or "Feature type NIV (7)" in ele:
				#print bound_summary[b]
				x=b
				for x in range(b,len(bound_summary)):
					ele = bound_summary[x]
					if "Lock Status" in ele:
						break
					if "type: " in ele and '7' not in ele:
						break
					if "Feature type" in ele and '7' not in ele:
						break
					if "Interface info for" in ele:
						print '<h3><font color="blue">'+ele+"</font></h3>"
					elif "ack_no" in ele or "type: 7" in ele or "Feature type NIV (7)" in ele:
						print '<font color="red">'+ele+'</font>'
					else:
						print ele
print '</div>'

print "<button class ='accordion'>Bound Interface details</button>"
print '<div class="panel">'
if len(bound_summary) == 0:
		        print 'No data Found as no IOM file is present'
else:
			print '<h3><i>Data Fetched from : `show system internal dcbx info interface eth-all` (IOM)</i></h3>'
			for ele in bound_summary:
				print ele
print '</div>'
	
port_channel = []
bound_channel = []
	#..

print "<button class='accordion'>Veth Attached Details</button>"
print '<div class = "panel">'
if len(veth_interface) == 0:
        print "No Data Found"
else:
	print '<h3><i>Data Fetched from : `show system internal vim info niv global`</i></h3>'
	for ele in veth_interface:
		print ele
print '</div>'

print"<button class='accordion'>VIM Trace logs</button>"
print '<div class ="panel">'
if len(veth_log) == 0:
        print "No Data Found"
else:
	for item in veth_log:	
        	print item
print '</div>'


print"<button class='accordion'>Vim Event History</button>"
print '<div class ="panel">'
if len(event_history_log) == 0:
        print "No Data Found"
else:
	for item in event_history_log:
        	print item
print '</div>'

#states
s=0
print "<button class='accordion'>Vim States</button>"
print '<div class="panel">'
print "<table id=customers>"
print "<tr><th colspan='9'>Event States for "+vethernet+"</th></tr>"
print "<tr><th>Timestamp</th><th>Previous State</th><th> Event </th> <th>Next State</th></tr>"
for s in range(min(len(event_m),len(time_m), len(next_state_m), len(prev_state_m) )):
        print "<tr>"
	print "<td>"
	print time_m[s]
	print "</td>"
        print "<td>"+prev_state_m[s]
        print "</td>"
        print "<td>"+event_m[s]+"</td>"
        print "<td>"+next_state_m[s]+"</td>"
        print "</tr>"
print "</table>"
print "<h3>Current State : "+c_state+"</h3>"

s=0
if len(event_n) >0:
 print "<table id=customers>"
 print "<tr><th colspan='9'>Event States for "+veth_name+" </th></tr>"
 print "<tr><th>Timestamp</th><th>Previous State</th><th> Event </th> <th>Next State</th></tr>"
 for s in range(min(len(event_n),len(time_n), len(next_state_n), len(prev_state_n) )):
        print "<tr>"
	print "<td>"
	print time_n[s]
	print "</td>"
        print "<td>"+prev_state_n[s]
        print "</td>"
        print "<td>"+event_n[s]+"</td>"
        print "<td>"+next_state_n[s]+"</td>"
        print "</tr>"
 print "</table>"
 print "<h3>Current State : "+c_state2+"</h3>"

if states_c == 'false':
	s=0
	change = ""
	for s in range(min(len(new_next), len(next_state_c))):
		if new_next[s]!= next_state_c[s]:
			change = new_next[s]
			break
	for s in range(len(next_state_c), len(new_next)):
		if change =="":
			change = new_next[s]
	s=0
	for s in range(len(event_n)):
		if change == next_state_n[s]:
			
			print "<table id=customers_r>"
			print "<tr><th colspan='9'>Changed state</th></tr>"
			print "<tr><th>Timestamp</th><th>Previous State</th><th> Event </th> <th>Next State</th></tr>"
		        print "<tr>"
		        print "<td>"
		        print time_n[s]
		        print "</td>"
		        print "<td>"+prev_state_n[s]
		        print "</td>"
		        print "<td>"+event_n[s]+"</td>"
		        print "<td>"+next_state_n[s]+"</td>"
		        print "</tr>"
			print "</table>"
			break 			
print '</div>'

# Ethpm
#Event-history
file = url+"/"+ path + "/"+side+"/sw_techsupportinfo";
eve = "Triggered event:"
prev = "Previous state:"
next = "Next state:"
cur = "Curr state:"
vethernet = "Vethernet"+veth_name.split("h")[1]
veth = veth_name
event_e = []
prev_state_e=[]
next_state_e=[]
c_state_e = ""
time1_e = []

ethpm_event_history_log = []

found = 0
if os.path.exists(file):
        text_new = '`show system internal ethpm event-history interface vethernet '+veth_name.split("h")[1]+'`'
        fp = open(file, "r");
	e = -1
        for line in fp:
                if text_new in line:
			ethpm_event_history_log.append('<h3><i>Data Fetched from : '+text_new+'</i></h3>')
                        line = line.rstrip('\n');
                        for line in fp:
				
                                if line.startswith('`show'):
                                        break;
                                line = line.replace("<", " ")
                                line = line.replace(">", " ")
                                ethpm_event_history_log.append(line.rstrip('\n'))
                                #Finding time
                                if "Transition" in line:
                                        words = line.split()
                                        for word in words:
                                                x = len(words)
                                                ts = words[x-5]+" "+words[x-4]+" "+words[x-3]+" "+words[x-2]+" "+ words[x-1]
                                                if 'usec' in word:
                                                        usec = words[words.index(word)-1]

                                        if e>0 and not len(next_state_e) != e:
                                                        next_state_e.insert(e,'-NO ENTRY-')
                                        if e>0 and not len(prev_state_e) != e:
                                                        prev_state_n.insert(e,'-NO ENTRY-')
                                        if e>0 and not len(event_e) != e:
                                                        event_e.insert(e,'-NO ENTRY-')

					e = e+1
					time1_e.insert(e,ts+' '+usec)
                                        
                                #Finding events
                                elif eve in line:
                                        words=line.split()
                                        for word in words:
                                                if "ETH" in word:
                                                        et=word.strip('[')
                                                        et=et.strip(']')        
							event_e.insert(e,et)
                                                        
                                #Finding previous state
                                elif prev in line:
                                        words= line.split()
                                        for word in words:
                                                if word.find("ETH") != -1:
                                                        st=word.strip('[')
                                                        st= st.strip(']')
							prev_state_e.insert(e,st)
                                                      
                                #finding next state
                                elif next in line:
                                        words = line.split()
                                        for word in words:
                                                if word.find("FSM") != -1:
                                                        nt = word.strip('[')
                                                        nt = nt.strip(']')
                                                        if 'FSM_ST_NO_CHANGE' in nt:
								next_state_e.insert(e,prev_state_e[e])
       							else:
								next_state_e.insert(e,nt)
                                                
                                #current state
                                if cur in line:
                                        words=line.split()
                                        for word in words:
                                                if word.find("ETH") != -1:
                                                	c_state_e = word.strip('[')
                                                        c_state_e = c_state_e.strip(']')
                                                                
        fp.close()

#trace_logs ethpm
ethpm_veth_log = []
v_name = 'Vethernet'+veth_name.split('h')[1]	#v_name = Vethernetxxx veth_name - vethxxx

#for large files, where vim_trace_log.1,2,3... exists
ethpm_trace_log = []
directory = url +"/"+path+"/"+side+"/sw_trace_logs"
#print directory
if os.path.exists(directory):
        result=os.listdir(directory)
        for l in result:
                if "ethpm_trace" in l:
                        #if not (l.endswith("current") or l.endswith("initial")):
                        ethpm_trace_log.append(l)
ethpm_trace_log.sort()
ethpm_trace_log.reverse()
#For all logs
for ele in ethpm_trace_log:
        file_log = url+"/"+path+"/"+side+"/sw_trace_logs/"+ele
        if os.path.exists(file_log):
                fp3= open(file_log,"r")
                for line in fp3:
                        if v_name in line or if_index in line:
	                        if '<h3><i>File name : sw_trace_logs/'+ele+'</i></h3>' not in ethpm_veth_log:
        	                        ethpm_veth_log.append('<h3><i>File name : sw_trace_logs/'+ele+'</i></h3>')

                                ethpm_veth_log.append(line.rstrip('\n'))
                fp3.close()

#ethpm logs
print"<button class='accordion'>Ethpm Logs</button>"
print '<div class="panel">'
if len(ethpm_veth_log) == 0:
        print "No Data Found"
else:
	for item in ethpm_veth_log:
        	print item
print '</div>'


print"<button class='accordion'>Ethpm Event History</button>"
print '<div class="panel">'
if len(ethpm_event_history_log) == 0:
        print "No Data Found"
else:
	for item in ethpm_event_history_log:
        	print item

print '</div>'

#states
s=0
print "<button class='accordion'>Ethpm States</button>"
print '<div class="panel">'
print "<table id=customers>"
print "<tr><th colspan='9'>Ethpm Event States for "+vethernet+"</th></tr>"
print "<tr><th>Timestamp</th><th>Previous State</th><th> Event </th> <th>Next State</th></tr>"
for s in range(min(len(event_e), len(time1_e),len(prev_state_e), len(next_state_e))):
        print "<tr>"
        print "<td>"
        print time1_e[s]
        print "</td>"
        print "<td>"+prev_state_e[s]
        print "</td>"
        print "<td>"+event_e[s]+"</td>"
        print "<td>"+next_state_e[s]+"</td>"
        print "</tr>"
print "</table>"
print "<h3>Current State : "+c_state_e+"</h3>"
print "\n"
print '</div>'

#if status is down, print ethpm logs, event history, states for bound interface
if status == "down":
 if bound_channel_new == []:
	bound_channel_new.append(bound)

 for bound_name in bound_channel_new:

	#Findinf if_index of eth
	e_if_index = "..if_index.."
	if os.path.exists(file):
        	#show interface snmp-ifindex
	        fp = open(file,"r")
        	for line in fp:
                	if '`show interface snmp-ifindex`' in line:
                        	line = line.rstrip('\n');
	                        for line in fp:
        	                        if line.startswith('`show'):
                	                        break;
                        	        line = line.replace("<", " ")
                                	line = line.replace(">", " ")
	                                words = line.split(" ")

        	                        if bound_name+' ' in line:
                	                        words = line.split()
                        	                for word in words:
                                	                if bound_name in word:
                                        	                e_if_index = words[words.index(word)+2]
                                                	        e_if_index = e_if_index.strip('(')
                                                        	e_if_index = e_if_index.strip(')')
	        fp.close();
	
	ethpm_veth_log = []
	e_name = 'Ethernet'+bound_name.split('h')[1]  
	
	#for large files, where vim_trace_log.1,2,3... exists
	#For all logs
	for ele in ethpm_trace_log:
        	file_log = url+"/"+path+"/"+side+"/sw_trace_logs/"+ele
	        if os.path.exists(file_log):
        	        fp3= open(file_log,"r")
                	for line in fp3:
                        	if e_name+' ' in line or e_name+'\n' in line or e_if_index in line:
                                	if '<h3><i>File name : sw_trace_logs/'+ele+'</i></h3>' not in ethpm_veth_log:
                                        	ethpm_veth_log.append('<h3><i>File name : sw_trace_logs/'+ele+'</i></h3>')

	                                ethpm_veth_log.append(line.rstrip('\n'))
        	        fp3.close()
	
	#ethpm logs
	print"<button class='accordion'>Ethpm Logs "+bound_name+"</button>"
	print '<div class="panel">'
	if len(ethpm_veth_log) == 0:
        	print "No Data Found"
	else:
        	for item in ethpm_veth_log:
                	print item
	print '</div>'
	#Event-history
	event_e = []
	prev_state_e=[]
	next_state_e=[]
	c_state_e = ""
	time1_e = []
	ethpm_event_history_log = []

	if os.path.exists(file):
        	text_new = '`show system internal ethpm event-history interface ethernet '+bound_name.split("h")[1]+'`'
	        fp = open(file, "r");
        	e = -1
	        for line in fp:
        	        if text_new in line:
				ethpm_event_history_log.append('<h3><i>Data Fetched from : '+text_new+'</i></h3>')
                	        line = line.rstrip('\n');
                        	for line in fp:

                                	#change to counter one
	                                if line.startswith('`show'):
        	                                break;
                	                line = line.replace("<", " ")
                        	        line = line.replace(">", " ")
                                	ethpm_event_history_log.append(line.rstrip('\n'))
	                                #Finding time
        	                        if "Transition" in line:
                	                        words = line.split()
                        	                for word in words:
                                	                x = len(words)
                                        	        ts = words[x-5]+" "+words[x-4]+" "+words[x-3]+" "+words[x-2]+" "+ words[x-1]
	                                                if 'usec' in word:
        	                                                usec = words[words.index(word)-1]

                                        	if e>0 and not len(next_state_e) != e:
                                                        next_state_e.insert(e,'-NO ENTRY-')
                                        	if e>0 and not len(prev_state_e) != e:
                                                        prev_state_n.insert(e,'-NO ENTRY-')
                                        	if e>0 and not len(event_e) != e:
                                                        event_e.insert(e,'-NO ENTRY-')

                                        	e = e+1
                                        	time1_e.insert(e,ts+' '+usec)
                	                       
	                                #Finding events
        	                        elif eve in line:
                	                        words=line.split()
                        	                for word in words:
                                	                if "ETH" in word:
                                        	                et=word.strip('[')
                                                	        et=et.strip(']')
                                                        	event_e.insert(e,et)

	                                #Finding previous state
        	                        elif prev in line:
                	                        words= line.split()
                        	                for word in words:
                                	                if word.find("ETH") != -1:
                                        	                st=word.strip('[')
                                                	        st= st.strip(']')
                                                        	prev_state_e.insert(e,st)

	                                #finding next state
        	                        elif next in line:
                	                        words = line.split()
                        	                for word in words:
                                	                if word.find("FSM") != -1:
                                        	                nt = word.strip('[')
                                                	        nt = nt.strip(']')
                                                        	if 'FSM_ST_NO_CHANGE' in nt:
                                                                	next_state_e.insert(e,prev_state_e[e])
	                                                        else:
        	                                                        next_state_e.insert(e,nt)

                	                #current state
                        	        if cur in line:
                                	        words=line.split()
                                        	for word in words:
                                                	if word.find("ETH") != -1:
                                                        	c_state_e = word.strip('[')
	                                                        c_state_e = c_state_e.strip(']')
	
        	fp.close()
	print"<button class='accordion'>Ethpm Event History "+bound_name+"</button>"
	print '<div class="panel">'
	if len(ethpm_event_history_log) == 0:
        	print "No Data Found"
	else:
        	for item in ethpm_event_history_log:
                	print item

	print '</div>'

	#states
	s=0
	print "<button class='accordion'>Ethpm States "+bound_name+"</button>"
	print '<div class="panel">'
	print "<table id=customers>"
	print "<tr><th colspan='9'>Ethpm Event States for "+bound_name+"</th></tr>"
	print "<tr><th>Timestamp</th><th>Previous State</th><th> Event </th> <th>Next State</th></tr>"
	for s in range(min(len(event_e), len(time1_e),len(prev_state_e), len(next_state_e))):
        	print "<tr>"
	        print "<td>"
	        print time1_e[s]
        	print "</td>"
	        print "<td>"+prev_state_e[s]
        	print "</td>"
	        print "<td>"+event_e[s]+"</td>"
	        print "<td>"+next_state_e[s]+"</td>"
        	print "</tr>"
	print "</table>"
	print "<h3>Current State : "+c_state_e+"</h3>"
	print "\n"
	print '</div>'

#portAg logs
port_file = url+"/"+path+"/"+side+"//var/sysmgr/sam_logs/svc_sam_portAG.log"
port_log = []
v_name = 'vethernet '+veth_name.split('h')[1]
if os.path.exists(port_file):
        fp3= open(port_file,"r")
        port_log.append('<h3><i>File Name : var/sysmgr/sam_logs/svc_sam_portAG.log</i></h3>')
        for line in fp3:
                if v_name in line:
                        port_log.append(line.rstrip('\n'))
        fp3.close()

#Vnic details
channel = ""
uif_id = ""
vnic_details = []
vnic_number = ""
mez_number = ""
start_vnic = ""
x =0 
for x in range(len(vnic)):
	file_path =  url+"/"+iom_path+"/AA/"+vnic[x]
	if os.path.exists(file_path):
		fp3 =  open(file_path, "r")
		for line in fp3:
			if 'vnic' in line:
				vnic_number = line
			if 'vifid' in line and channel in line:
				start_vnic = vnic_number
				mez_number = vnic[x]					
				break
		fp3.close()

file_path =  url+"/"+iom_path+"/AA/"+mez_number
if os.path.exists(file_path):
	fp3 = open(file_path, "r")
	for line in fp3:
		if start_vnic in line:
			vnic_details.append('<h3><i>Data Fetched from : '+mez_number+' (IOM)</i></h3>')
			vnic_details.append(line.rstrip('\n'))
			for line in fp3:
				if 'vnic' in line:
					break
				vnic_details.append(line.rstrip('\n'))
	fp3.close()

print"<button class='accordion'>vnic configuration</button>"
print '<div class="panel">'
if len(vnic_details) == 0:
	print "No Data Found"
else:
	for ele in vnic_details:
		print ele
print '</div>'

#debugdump debug[] //list with all files
x = 0
debug_data = []
debug_path = ""
for x in range(len(debug)):
        file_path =  url+"/"+iom_path+"/AA/"+debug[x]
        if os.path.exists(file_path):
                fp3 =  open(file_path, "r")
                for line in fp3:
			if ' '+channel+' ' in line:
				debug_path = debug[x]
				words = line.split(' ')
				for word in words:
					if word.startswith('=>'):
						uif_id = word.split('>')[1]
				break
		fp3.close()

file_path = url+"/"+iom_path+"/AA/"+debug_path
if os.path.exists(file_path):
	fp3 = open(file_path,"r")
	for line in fp3:
		if 'uif '+uif_id in line:
			debug_data.append('<h3><i>Data Fetched from : '+debug_path+' (IOM)</i></h3>')
			debug_data.append(line.rstrip('\n'))
			for line in fp3:
				if '##' in line:
					break
				debug_data.append(line.rstrip('\n'))
			break
	fp3.close()

print"<button class='accordion'>Debug dump</button>"
print '<div class="panel">'
if len(debug_data) == 0:
        print "No Data Found"
else:
        for ele in debug_data:
                print ele
print '</div>'


#Accounting log
acc_log = []
if os.path.exists(file):
	fp = open(file, "r")
	for line in fp:
		if '`show accounting log ' in line:
                	line = line.rstrip('\n');
                        for line in fp:
                        	if line.startswith('`show'):
                                	break;
                                line = line.replace("<", " ")
                                line = line.replace(">", " ")
				if veth_name.split('h')[1] in line:
                                	acc_log.append(line.rstrip('\n'))

        fp.close();

print"<button class='accordion'>Accounting logs</button>"
print '<div class="panel">'
if len(acc_log) == 0:
        print "No Data Found"
else:
	print '<h3><i>Data Fteched from : `show accounting log`</i></h3>'
	for item in acc_log:
        	print item
print '</div>'

#PortAG logs
print"<button class='accordion'>PortAg logs</button>"
print '<div class="panel">'
if len(port_log) == 0:
        print "No Data Found"
else:
	for item in port_log:
        	print item
print '</div>'
