#!/usr/bin/python
#!/usr/bin/env python

from itertools import islice
print "Content-Type: text/plain;charset=utf-8\n"
import shlex
import cgi
import cgitb
import os
import time
import string
import re

cgitb.enable()
form = cgi.FieldStorage()
username = form.getvalue("username")
username = str(username)
list = []
j = 0
path = "tmp"
if os.path.exists(path):
       
	dirs = os.listdir(path)
	for i in dirs:
		if re.match(username + "\w_.*", i):
                        
			list.append(i)
			path1 = path + "/" + i
			fol = os.listdir(path1)
			for item in fol:
				item = str(item)
				item = item.replace("backslash", "/")
				item = str(item)
				list[j] = list[j] + "path-" + item
				j = j + 1
        
	print list
