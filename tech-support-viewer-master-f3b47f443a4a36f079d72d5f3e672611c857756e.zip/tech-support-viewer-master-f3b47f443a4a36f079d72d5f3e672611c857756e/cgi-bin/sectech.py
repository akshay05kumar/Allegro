#!/usr/bin/python
#!/usr/bin/env python
import os
import shlex
import cgi
import sys
import datetime
import time
import string
clivar = " " #clivar is used just to check weather cli is running or from GUI"
form = cgi.FieldStorage()
path = form.getvalue("second")
user = form.getvalue("user")
bugid=form.getvalue("bug")
bugid1=str(bugid)
clivar = form.getvalue("count")
if clivar == "1":
	print "Content-Type: text/plain;charset=utf-8\n"
if clivar != "1":
	path = str(sys.argv[2])
	user = str(sys.argv[1])
default_path="/auto/ucsb-qa/cdets/"
pathwithbugid=default_path+bugid1
pathwithbugid=str(pathwithbugid)
#if not (os.path.exists(pathwithbugid)):
#    print "NO MATCH FOUND WITH THIS BUGID"
count=0
if (bugid) :
 for file in os.listdir(pathwithbugid):
    if file.endswith("UCSM.tar"):
        file=str(file)
        count=count+1
        
        path11=pathwithbugid+"/"+file 
 path11.strip('/n')
 path11.strip("/")
 path=path11
path1 = path.replace("/","backslash")
path1 = str(path1)
#user=form.getvalue("user")
cwd = os.getcwd()
ts = time.time()
#path = "/users/shgudipa/20150105085948_cdvr-fi-mana-a-01_UCSM.tar"
dir_name = path.split("/")
dir_name_tmp = dir_name[-1]
dir_name_final = dir_name_tmp.split(".")[0]
# to save every user login info we used "st" variable
# sta  and sta2  are  used to store paths that were used by any username  i.e suggested paths for next time
st = user + str(ts) + "/"
sta = user + "_" + str(ts) + "/"
sta2 = path1 + "/"
top_of_root = "tmp/"
import subprocess
if (os.path.exists(path) and clivar=="1"):
    new_path = "tmp/" + st
    newpath1 = "tmp/" + sta
    newpath2 = str(newpath1) + sta2
    os.system("mkdir -p " + new_path + " > /dev/null")
    os.system("mkdir -p " + newpath1 + " > /dev/null")
    os.system("mkdir -p " + newpath2 + " > /dev/null")
   
    os.system("cd " + new_path + ";tar -xvf " + path + " > /dev/null")
    #subprocess.Popen(["cd", new_path], stdout=subprocess.PIPE)
    df = subprocess.Popen(["ls",new_path], stdout=subprocess.PIPE)
    output=df.communicate()[0]
    
    
    
    output=str(output)
    dir_name_final=output
    dir_name_final.replace("\n", "");
    dir_name_final = dir_name_final.rstrip('\r\n')
    
    if os.path.isfile("tmp/" + st + dir_name_final + "/UCSM_A_TechSupport.tar.gz"):
        
        os.system("cd tmp/" + st + dir_name_final + ";mkdir A;cd A;tar -xzvf ../UCSM_A_TechSupport.tar.gz > /dev/null")
    if os.path.isfile("tmp/" + st + dir_name_final + "/UCSM_B_TechSupport.tar.gz"):
        os.system("cd tmp/" + st + dir_name_final + ";mkdir B;cd B;tar -zxvf ../UCSM_B_TechSupport.tar.gz > /dev/null")
    if clivar=="1":
        print(st + dir_name_final + "/")
    os.system("chmod -R 777 tmp/" + st)
    os.system("chmod -R 777 tmp/" + sta)
else:
    print " "
