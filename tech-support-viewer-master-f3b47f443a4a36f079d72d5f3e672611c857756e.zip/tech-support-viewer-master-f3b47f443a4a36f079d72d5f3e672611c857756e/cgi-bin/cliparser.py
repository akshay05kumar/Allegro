#!/ws/sjc-nuoBuild01/savbu-bin/python
#!/usr/bin/env python
from itertools import islice
#print "Content-Type: text/plain;charset=utf-8\n"
import shlex
import cgi
import os
import time
import string
import sys
import getpass
import subprocess
#import property
from property import url
from property import scriptpath

helps = 0
user = getpass.getuser()
df = subprocess.Popen(["df", url], stdout=subprocess.PIPE)
output = df.communicate()[0]
output1 = output.split("\n")
#output2 = output1[2].split(" ")
#var1 = output2[-4]
#var1 = int(var1)
#result = var1/(1024*1024)
#if result > 5:
#	print ""
#else:
#	print ""
var1=os.getcwd();



for args in sys.argv:
	if sys.argv[1] == "--path":
		path2 = (sys.argv)[2]
               
		os.system("python "+scriptpath+"/create_ws.py" + " " + user + " " + path2)
                
		helps = 1
		break;

if helps == 1:
	#load_source(create_ws.py, '/ws/sjc-nuo31/sukatara/tech-support-viewer/cgi-bin/')
	sys.path.append(scriptpath)
if "--path" in sys.argv:
 path = path2
 path1 = path.replace("/","backslash")
 path1 = str(path1)
 ts = time.time();
 dir_name = path2.split("/")
 dir_name_tmp = dir_name[-1]
 dir_name_final = dir_name_tmp.split(".")[0]
 st = user+str(ts)+"/"
 sta = user+"_"+str(ts)+"/"
 sta2 = path1+"/"
 top_of_root = "tmp/"
 tuio = st+dir_name_final+"/"

if os.path.exists(path):
  var2=path
else:
 var2=str(var1)+"/"+str(path)


if helps == 1 and "--path" in sys.argv:
   new_path = url  +"/"+ st
   newpath1 = url + "/"+sta
   newpath2 = str(newpath1)+sta2

   os.system("mkdir -p " + new_path + "> /dev/null")
   os.system("mkdir -p " + newpath1 + "> /dev/null")
   os.system("mkdir -p " + newpath2 + "> /dev/null")
   os.system("cd " + new_path + ";pwd > /dev/null;tar -xvf " + var2 + "> /dev/null")
   
   if os.path.isfile(url +"/" +st + dir_name_final + "/UCSM_A_TechSupport.tar.gz"):
                
		os.system("cd "+url +"/"+ st + dir_name_final + ";mkdir A;cd A;tar -xzvf ../UCSM_A_TechSupport.tar.gz > /dev/null")

   if os.path.isfile(url +"/" + st + dir_name_final + "/UCSM_B_TechSupport.tar.gz"):
		os.system("cd "+url +"/"+ st + dir_name_final + ";mkdir B;cd B;tar -zxvf ../UCSM_B_TechSupport.tar.gz > /dev/null")

# os.system("cd tmp/"+new_path"+/B;tar -xvf UCSM_B_TechSupport.tar.gz B")
#tuio is the client_id which is rewuired for further files
   tuio = str(tuio)
if len(sys.argv) == 3:
	
	os.system("echo HEALTH;python "+scriptpath+"/health.py" + " " + user + " " + tuio)
	os.system("echo SCALING;python "+scriptpath+"/get_scaling.py" + " " + user + " " + tuio)
	
	os.system("echo INVENTORY;python "+scriptpath+"/inventory.py" + " " + user + " " + tuio)
	
	os.system("echo FULL INVENTORY;python "+scriptpath+"/get_inventory.py" + " " + user + " " + tuio)

for args in sys.argv:
	if "--help" in args	:
		print "Usage:"
		print "cliparser.py  --path <path> [scale] [health] [fullinv] [inventory]"
		print "OR"
		print "cliparser.py [--help]"

		print "--scale	     Gives scale of various things in that file"
		print "--health	 Gives health(CRC errors , error disabled interface , show cores)"
		print "--fullinv	 Gives full inventory"
		print "--inventory  Gives summarized inventory"
		print "--help	     Gives usage overview"

	if  "--health" in args:
		os.system("python "+scriptpath+"/health.py" + " " + user + " " + tuio)

	if  "--scale" in args:
		os.system("python "+scriptpath+"/get_scaling.py" + " " + user + " " + tuio)

	if  "-i" in args or "--inventory" in args:
		os.system("python "+scriptpath+"/inventory.py" + " " + user + " " + tuio)

	if "--fullinv" in args:
		os.system("python "+scriptpath+"/get_inventory.py" + " " + user + " " + tuio)
