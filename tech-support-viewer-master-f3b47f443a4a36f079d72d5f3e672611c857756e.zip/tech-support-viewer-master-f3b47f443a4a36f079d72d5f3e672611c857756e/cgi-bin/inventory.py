#!/usr/bin/python
#!/usr/bin/env python

import os
import sys
import cgi
from property import url
import pprint

form = cgi.FieldStorage()
clivar = form.getvalue("count")
help = clivar
side = form.getvalue("side")

if clivar=="1":
	print "Content-Type: text/plain;charset=utf-8\n"
	path=form.getvalue("id")
else:
	path=str(sys.argv[2])

#path = form.getvalue("path") // get path from harsh
#print(os.path.exists(file))
cwd=os.getcwd()
"""if help=="1":
	file1= "tmp/"+path+"/"+"sw_techsupportinfo"
else:
	file=cwd+"/tmp/"+path+"/"+"/sw_techsupportinfo";
"""
file1= url+"/"+path+"/"+"sw_techsupportinfo"

command_show_switchname = "show switchname"
command_show_system_uptime = "System uptime"
command_show_module = "show module"
command_show_version = "show version"
command_show_mgmt_ip = "show interface mgmt0"
command_show_pinning="show pinning-border-interfaces"
switchname = ""
module = ""

version = ""
uptime = ""
status = ""
mgmt_ip = ""

_sentinel = object()
listia={}
def next(it, default=_sentinel):
	try:
		return it.next()
	except StopIteration:
		if default is _sentinel:
			raise
		return default

#parsing inventory information
def getInventory(side):
        switchname = ""
	module = ""
	version = ""
	uptime = ""
	status = ""
	mgmt_ip = ""
	endhost = 0
	mode = 0
	listia[side]={}
	module = ""
	status = ""
	"""if help=="1":

	 file = "tmp/file1= "tmp/"+path+"/"+"sw_techsupportinfo"

	else :
	 file=cwd+"/tmp/"+path+"/"+side+"/sw_techsupportinfo";
	"""
	file=url+"/"+path+"/"+side+"/sw_techsupportinfo";
        
	if os.path.exists(file) or os.path.exists(file1):
		fp = open(file,"r")
		for line in fp:
			if "`show running-config | grep -v username" in line:
				# line = next(fp)
				line = line.rstrip('\n')
				mode=0
				for line in fp:
					if line.startswith("`show"):
						break;
					if "feature npv" in line:
						mode=1
		fp.close()

		fp = open(file,"r")
		for line in fp:
			if "`show pinning border-interfaces" in line:
				# line = next(fp)
				line = line.rstrip('\n')
				# print(line)
				endhost = 1
		fp.close()

		fp = open(file,"r")
		for line in fp:
			if command_show_switchname in line:
				line = next(fp)
				line = line.rstrip('\n')
				# print(line)
				switchname = line
		fp.close()

		fp = open(file,"r");
		for line in fp:
			if command_show_system_uptime in line:
				line = line.rstrip('\n')
				line = line.replace(" ","")
				# print(line)
				uptime = line
		fp.close()

		fp = open(file,"r");
		for line in fp:
			if command_show_module in line:
				line = next(fp)
				line = next(fp)
				line = next(fp)
				word = line.split(" ")
				for s in word:
					if "SUP" in s:
						listia[side]["Name"]=s
						if clivar=="1":
							print(s)
						module = s
						status = word[17]
						break
		fp.close()

		fp = open(file,"r");
		for line in fp:
			if command_show_version in line:
				line = next(fp)
				for line in fp:
					if "system:" in line:
						line = line.rstrip('\n')
						word = line.split(" ")
						#print(word[9])
						#print(word[10])
						if "gdb" in line:
							version = line # word[7]+word[8]+word[9]+word[10]
						else:
							version = line #word[7]
						break
		fp.close()

		fp = open(file,"r");
		for line in fp:
			if command_show_mgmt_ip in line:
				line = next(fp)
				line = next(fp)
				line = next(fp)
				line = line.rstrip('\n')
				line = line.lstrip()
				mgmt_ip = line
				# print(line)
				break
		fp.close()

		listia[side]["SystemName"]= switchname
		listia[side]["InternetAddress"]= mgmt_ip
		listia[side]["Version"]=version
		listia[side]["uptime"]=uptime
		listia[side]["Model"]=module

		if clivar=="1":
			print("System Name: "+switchname)
			# listia[side]["SystemName"]=switchname
			print(mgmt_ip)
			# listia[side]["InternetAddress"]=mgmt_ip
			print("Version: "+version)
			# listia[side]["Version"]=version
			print(uptime)
			# listia[side]["uptime"]=uptime
			print("Model: " + module + " Status: " + status)
			# listia[side]["Model"]=module
			if endhost == 1:
				print"Ethernet is in End Host Mode"
			if mode == 1:
				print"FC is in NPV Mode"
			if mode == 0:
				print"FC is in Switching Mode"
	else:
		print("")

"""if help=="1":
	file = "tmp/"+path+"/"+"A"+"/sw_techsupportinfo";
	file1= "tmp/"+path+"/"+"sw_techsupportinfo";

else :
	file =cwd+"/tmp/"+path+"/"+"A"+"/sw_techsupportinfo";
	file1= cwd+"/tmp/"+path+"/"+"sw_techsupportinfo";
"""
file = url+"/"+path+"/"+"A"+"/sw_techsupportinfo";
file1= url+"/"+path+"/"+"sw_techsupportinfo";


# file = "../tmp/sample1/UCSM_A_TechSupport/sw_techsupportinfo
if os.path.exists(file) or os.path.exists(file1) :
	side = "A"
        
       
     
	getInventory( side )

print("---------------------------------------------")
cwd = os.getcwd()
"""if help=="1":
	file = "tmp/"+path+"/"+"B"+"/sw_techsupportinfo";
else:
	file = cwd+"/tmp/"+path+"/"+"B"+"/sw_techsupportinfo";
"""
file = url+"/"+path+"/"+"B"+"/sw_techsupportinfo";

# file = "../tmp/sample1/UCSM_A_TechSupport/sw_techsupportinfo"
if os.path.exists(file) or os.path.exists(file1):
	side = "B"
	getInventory( side )
if clivar!="1":
      pprint.pprint(listia)


