#!/usr/bin/python
#!/usr/bin/env python

import os
import sys
from property import url
import pprint
listia={}
sum=" "
import cgi
form = cgi.FieldStorage()
side=form.getvalue("side")
command=form.getvalue("command")
path=form.getvalue("id")
sum=form.getvalue("count")
sum1=sum
if sum=="1":
	print "Content-Type: text/plain;charset=utf-8\n"
if sum!="1":
	path=str(sys.argv[2])

def macfunction(side):

 
 hard="`show platform fwm info hw-stm asic"
 soft="`show mac address-table"
 side=str(side)
 cwd=os.getcwd()

                           


 """if sum=="1":
  file="tmp/"+path+"/"+side+"/sw_techsupportinfo";
 else:
   file=cwd+"/tmp/"+path+"/"+side+"/sw_techsupportinfo";"""
 file="tmp/"+path+"/"+side+"/sw_techsupportinfo";
 maclist=[]
 hardlist=[]
 
 if os.path.exists(file):
    
    fp=open(file,"r+");
    for line in fp:
     if line.startswith(soft):
       for line in fp:
         if line.startswith("*"):
           
             lino=line.split( )
             maclist.append(lino[2])
         if line.startswith("`show"):
            
             break;
     if line.startswith(hard):
        temp=line
        count=0
        for line in fp:
          if line.startswith("Invalid"):
              print line
              break;   
          if line.startswith("---"):
            for line in fp:
               limo=line.split()
               
               hardlist.append(limo[1])
               if line.startswith("`show") or line.startswith("DA"):
                    
                    break;
                      
            for item in maclist:
                 if item not in hardlist:
                   temp=temp.strip("\n") 
                   print temp+" doesn't contains address "+item
                   
            hardlist=[]
           
            count=1
          if count==1:
                break;                 





#path = form.getvalue("path") // get path from harsh
#ath="sample1"
var2="0 CRC"
var1="`show interface`"
command_core = "show cores"
command_reset_reason = "show system reset-reason"
interface_brief = "show interface brief"
interfacedic={}
#show cores output
_sentinel = object()
def next(it, default=_sentinel):
    try:
        return it.next()
    except StopIteration:
        if default is _sentinel:
            raise
        return default
cwd=os.getcwd();
def show_health( side ):
    
    ratio= "`show interface`"
    file ="tmp/"+path+"/"+side+"/sw_techsupportinfo"
    
    if os.path.exists(file):
     fp=open(file,"r")
     for line in fp:
      if line.startswith(ratio):
           for line in fp:
              if line.startswith("Ethernet") or line.startswith("Br-Ethernet")  or line.startswith("port-channel"):
                   
                   ethtemp=line.split()[0]
                   eth_dic={}
                   for line in fp:
                      if "30 seconds input rate" in line or "0 seconds output rate" in line:
                        line2=line.split(",")
                        eth_dic["INPUT_RATE"]=line2[-1]

                      if  "30 seconds output rate" in line or "0 seconds output rate" in line:
                           line3=line.split(",")
                           eth_dic["OUTPUT_RATE"]=line3[-1]
                      if "RX" in line:
                          for line in fp:
                             line1= line.split()
                             line1[0]=int(line1[0])
                             line1[3]=int(line1[3])
                             line1[6]=int(line1[6])
                             sum=int(line1[0])+int(line1[3])+int(line1[6])
                             if sum!=0:
                              uni= line1[0]*100 /sum
                              mult= line1[3]*100 /sum
                              broad = line1[6]*100 / sum 
                             else:
                              uni=0
                              mult=0
                              broad=0
                             temp_dic={}
                             temp_dic["unicast"]=uni
                             temp_dic["multicast"]=mult
                             temp_dic["broadcast"]=broad
                             eth_dic["RX"]=temp_dic
                             break;
                      if "TX" in line:
                          for line in fp:
                             line1= line.split()
                             line1[0]=int(line1[0])
                             line1[3]=int(line1[3])
                             line1[6]=int(line1[6])
                             sum=int(line1[0])+int(line1[3])+int(line1[6])
                             if sum!=0:

                              uni= line1[0]*100 /sum 
                              mult= line1[3]*100 /sum 
                              broad = line1[6]*100 / sum
                             else:
                               uni=0
                               mult=0
                               broad=0
                             temp_dic={}
                             temp_dic["unicast"]=uni
                             temp_dic["multicast"]=mult
                             temp_dic["broadcast"]=broad
                             eth_dic["TX"]=temp_dic
                             break;
                      if line.startswith("\n"):
                        interfacedic[ethtemp]=eth_dic
                        break;
              if line.startswith("`show"):
                     break;
    
    """   
    print "<table id=customers>"
    print "<tr><th>   </th> <th colspan='3'> RX </th>  <th colspan='3'> TX </th></tr>" 
    print "<tr><td>  </td> <td>UNICAST</td> <td>MULTICAST</td>  <td> BROADCAST</td>  <td>UNICAST</td> <td>MULTICAST</td>  <td> BROADCAST</td></tr> "
    for key in interfacedic:
      print "<tr>"
      print "<td>%s"%key  
      print "</td>" 
      for ke1 in interfacedic[key]:
        print "<td>%s"%interfacedic[key][ke1]['unicast'] 
        print"</td>"
        print "<td>%s"%interfacedic[key][ke1]['multicast'] 
        print "</td>"
        print "<td>%s"%interfacedic[key][ke1]['broadcast']
        print "</td>"
      print "</tr>"



    
    
    if sum1=="1":

     file = "tmp/"+path+"/"+side+"/sw_techsupportinfo";
    else:
     file=cwd+"/tmp/"+path+"/"+side+"/sw_techsupportinfo";
    """
    file = url+"/"+path+"/"+side+"/sw_techsupportinfo";
    print("Show CRC errors\n")
    if os.path.exists(file):
        fp = open(file,"r+");
        text="`show interface`"
        list=[]
        var5="CRC"
        count=0
        for line in fp:

                if text in line:

                        line = line.rstrip('\n');

                        for line in fp:

                                if line.startswith('`show'):

                                        break;
                                # print(line.rstrip('\n'))
                                list.append(line)
                        string="".join(str(x) for x in list)
                        list2= string.split('\n\n')
                        for str1 in  list2:
                           var3= str1.find(var2)
                           if var3== -1:
                              var4=str1.find(var5)
                              if var4>0:
                                 count=1
                                 print str1 
                                 
        if count!=1:
              print "        no errors found"                      
                              



        print"Show Cores"        
        sum=0
        for line in fp: 
                 
            if command_core in line:
            
                line=next(fp)
                line=next(fp)
                line=next(fp)
                line = line.rstrip('\n')
                #print(line)
                for line in fp:
                    line = line.rstrip('\n')
                    if line.startswith("`show"):
                        break
                    else:
                        sum=1
                        print(line)
                        
        if sum!=1:
             print "           no data found"
        fp.close()               
    else:
        print("")
    print("\nShow System Reset-Reason\n")
    if os.path.exists(file):
        fp = open(file,"r");
        for line in fp:
            
            if command_reset_reason in line:
                #print(line)
                for line in fp:
                    line = line.rstrip('\n')
                    if line.startswith("`show"):
                        break
                    else:
                        print(line)
        fp.close()               
    else:
        print("")
    lon=0
    print("\n<b>Error disabled interfaces:</b> \n")
    if os.path.exists(file):
        fp = open(file,"r");
        for line in fp:

            if interface_brief in line:
                #print(line)
                for line in fp:
                    line = line.rstrip('\n')
                    if line.startswith("`show"):
                        break
                    else:
                        if "errDisabled" in line:
                            print(line)
                            lon=1

        fp.close()                   
    if lon!=1:
        print "                no data found"
    else:
        print("")
mamoth=0
side = "A"
print("\n--------------------A-side--------------------\n")
show_health(side)

print ("\n")
if sum=="1":
 print "<table id=customers>"
 print "<tr><th colspan='9'>INTERFACE PACKETS INFO SIDE A </th></tr>"
 print "<tr><th>  </th><th>INPUT RATE</th><th colspan='3'> RX </th>  <th colspan='3'> TX </th> <th>OUTPUT RATE</th></tr>"
 print "<tr><td>  </td> <td> </td><td>UNICAST</td> <td>MULTICAST</td>  <td> BROADCAST</td>  <td>UNICAST</td> <td>MULTICAST</td>  <td> BROADCAST</td><td> </td></tr> "
 for key in interfacedic:
      print "<tr>"
      print "<td>%s"%key
      print "</td>"
      for ke1 in interfacedic[key]:
        if ke1 =="INPUT_RATE" or ke1=="OUTPUT_RATE":
         print "<td>%s"%interfacedic[key][ke1]
         print "</td>"
        else:
         print "<td>%s"%interfacedic[key][ke1]['unicast']
         print"</td>"
         print "<td>%s"%interfacedic[key][ke1]['multicast']
         print "</td>"
         print "<td>%s"%interfacedic[key][ke1]['broadcast']
         print "</td>"
      print "</tr>"

if sum!="1":
  print "A SIDE INTERFACE PACKETS INFO"



  pprint.pprint( interfacedic)







print("\n")
"""if sum1!="1":

 file=cwd+"tmp/"+path+"/"+side+"/sw_techsupportinfo"

else:
  file="/tmp/"+path+"/"+side+"/sw_techsupportinfo";
"""
file=url+"/"+path+"/"+side+"/sw_techsupportinfo";


if os.path.exists(file):
 fp=open(file,"r")
 for line in fp:
  if "show module" in line:
   line=next(fp)
   line=next(fp)
   line=next(fp)
   word=line.split(" ")
   for s in word:
    
    if"UCS-FI-62" in s:
       mamoth=1
       print ("MAC address information")

       macfunction(side)
 fp.close();
side = "B" 
print("\n----------B-side--------------------\n")
show_health(side)
print("\n")
if sum=="1":
 print "<table id=customers>"
 print "<tr><th colspan='9'>INTERFACE PACKETS INFO SIDE B </th></tr>"
 print "<tr><th>  </th><th>INPUT RATE</th><th colspan='3'> RX </th>  <th colspan='3'> TX </th> <th>OUTPUT RATE</th></tr>"
 print "<tr><td>  </td> <td> </td><td>UNICAST</td> <td>MULTICAST</td>  <td> BROADCAST</td>  <td>UNICAST</td> <td>MULTICAST</td>  <td> BROADCAST</td><td> </td></tr> "
 for key in interfacedic:
      print "<tr>"
      print "<td>%s"%key
      print "</td>"
      for ke1 in interfacedic[key]:
        if ke1 =="INPUT_RATE" or ke1=="OUTPUT_RATE":
         print "<td>%s"%interfacedic[key][ke1]
         print "</td>"
        else:
         print "<td>%s"%interfacedic[key][ke1]['unicast']
         print"</td>"
         print "<td>%s"%interfacedic[key][ke1]['multicast']
         print "</td>"
         print "<td>%s"%interfacedic[key][ke1]['broadcast']
         print "</td>"
      print "</tr>"



if sum!="1":
   print "B SIDE INTERFACE PACKETS INFO"



   pprint.pprint( interfacedic)


if mamoth==1:
 print ("MAC address information")
 macfunction(side)
