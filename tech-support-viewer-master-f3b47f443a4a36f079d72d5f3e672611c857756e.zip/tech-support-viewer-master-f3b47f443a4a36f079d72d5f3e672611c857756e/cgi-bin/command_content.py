#!/usr/bin/python
#!/usr/bin/env python

from itertools import islice
import shlex
import cgi
import cgitb; cgitb.enable()
import os
import time

#print "Content-Type: text/xml;charset=utf-8\n"

print "Content-Type: text/plain;charset=utf-8\n"

from property import url
form = cgi.FieldStorage()
side = form.getvalue("side")
side = str(side)
side = side.upper()
filter=form.getvalue("filter")
text = form.getvalue("text")
text = str(text)
text=text.replace('^','/')
type = form.getvalue("type")
type = str(type)
path = form.getvalue("id")
path = str(path)
page = form.getvalue("page")

if len(page)>2:
	page1= int(page[0])*10+int(page[1])
else:
	page1 = page[0]
page1 = int(page1);

i = 0
page_depth = 10000;
count =0
mez = form.getvalue("mez_value");

if type == "file" :
	if filter == "1":
		#file = url+"/"+ path + "/" + side + "/sw_trace_logs/" + text;
                file = url+"/"+ path + "/" + side + "/" + text;

	elif text == 'debugdump':
		file = url+"/"+path+"/AA/"+mez+"/"+text;
	elif text =='vnic.cfg':
		file = url+"/"+path+"/AA/"+mez+"/config/"+text;
	else:
		file = url+"/"+path+"/AA/"+mez+"/obfl/obfl/"+text;

	if os.path.exists(file):
	
		start_from = page1 * page_depth
		fp = open(file,"r");

		page1 = page1 + 1
		print "Page : ",
		print page1
		for line in fp:
			if count < page1 * page_depth and count >= start_from:
				print(line.rstrip('\n'))
			count = count + 1
		total_page = count / page_depth
		remaining = count / page_depth
		remaining = remaining +1
		print "\n\nTotal number of pages : " + " " + str(remaining)
			
		fp.close()
	else:
		print("NO FILE FOUND")

else:   
        if filter=="1":
	 file = url+"/"+ path + "/" + side + "/sw_techsupportinfo";
        else :		
        	if side=="A":
        		temp="techsupport_detailed_iocard1"  
        	else :
       			temp="techsupport_detailed_iocard2"
		file = url+"/"+path+"/"+side+"/"+temp+"/"+"nxos"+"/show-tech-support-iom-nxos.out";
	
	if os.path.exists(file):
		# command = raw_input("Enter command name: ");
		fp = open(file, "r");
		for line in fp:
				if text in line:
						line = line.rstrip('\n');
						for line in fp:
								if line.startswith('`show'):
										break;
								line = line.replace("<", " ")
								line = line.replace(">", " ")
								print(line.rstrip('\n'))

		fp.close();
	else:
		print("NO FILE FOUND")
