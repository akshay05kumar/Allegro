
#!/usr/bin/python
#!/usr/bin/env python

import os
import sys
import cgi

import pexpect
print "Content-Type: text/plain;charset=utf-8\n"
form = cgi.FieldStorage()
path = form.getvalue("path")
user = form.getvalue("user")
clivar = form.getvalue("count")
serverIP = "sav-fx-tsv:/home/webserver/"
username = "webserver"
password = "nbv-cisco"
shell = pexpect.spawn("scp " +path + " "+username + "@" + serverIP)
shell.expect("assword:")
shell.sendline(password)

print "hello"


