#!/usr/bin/python
#!/usr/bin/env python
import os
import cgi
print "Content-Type: text/plain;charset=utf-8\n"
form = cgi.FieldStorage()
side = form.getvalue("side")
command = form.getvalue("command")
path = form.getvalue("id")
if side=="A":
  
  temp="techsupport_detailed_iocard1"
else:
  
  temp="techsupport_detailed_iocard2"

file = "tmp/"+path+"/"+side+"/"+temp+"/"+"nxos"+"/show-tech-support-iom-nxos.out";

if os.path.exists(file):
        
	fp = open(file,"r");
	for line in fp:
		if line.startswith('`show'):
			line = line.rstrip('\n')
			print(line)
else:
	print("NO IOM FOUND")
