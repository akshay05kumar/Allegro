#!/usr/bin/python
#!/usr/bin/env python

from itertools import islice
print "Content-Type: text/plain;charset=utf-8\n"
import shlex
import cgi
import cgitb
import os
import time
import string
import re

cgitb.enable()
form = cgi.FieldStorage()

bugid=form.getvalue("bugid")
bugid=str(bugid)


list = []
j = 0
count=0

path1="/auto/ucsb-qa/cdets/"

bugpath=[]
fullbugpath=[]
if bugid :
  dirs=os.listdir(path1)
  for item in dirs:
     item=str(item)
     
     if bugid in item:
       
       path2=path1+item+"/"
       if os.path.exists(path2):

        dirs = os.listdir( path2 )
        for file in dirs:
             count=count+1

             if ".tar" in file:
                
                bugpath.append(file)


  for item in bugpath:
    item=str(item)
    temp=path2+item
    fullbugpath.append(temp)



  print fullbugpath

