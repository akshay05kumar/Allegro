#!/usr/bin/python
#!/usr/bin/env python
import os
import cgi
from os import walk
print "Content-Type: text/plain;charset=utf-8\n"

form = cgi.FieldStorage()
side = form.getvalue("side")
path = form.getvalue("id")
#path = form.getvalue("path") // get path from harsh
file = "tmp/" + path + "/" + side;

if os.path.exists(file):
	f = []
	for (dir, _, files) in os.walk(file):
		for f in files:
			paths = os.path.join(dir, f)
			if os.path.exists(paths):
        			i =  paths.split('/'+side+'/')[1]
				if i.endswith(".gz"):
                        		name = i.split(".")[0]+"."+i.split(".")[1]
                       			print name
                        		# unzip : gzip -d file.gz
                        		os.system("cd tmp/"+path+"/"+side+"; gzip -d "+i+"")
                		else:
                        		print (i)


else:
	print "No File Found"
