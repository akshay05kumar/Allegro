#!/usr/bin/python
#!/usr/bin/env python
print "Content-Type: text/plain;charset=utf-8\n"

import cgi
import os
import sys
import pprint
from property import url

form = cgi.FieldStorage()
clivar=form.getvalue("count")
help=clivar
side=form.getvalue("side")
command=form.getvalue("command")
if clivar=="1":
 path=form.getvalue("id")
else:

 path=str(sys.argv[2])
 clidic={ }
listia={}
listib={}
maindic={ }
mainiodic={ }
lista=[]
temp3=[]
NJCH=0
count=0
count1=0
cwd=os.getcwd()

var1="`show chassis inventory expand`"
var2="`show server status detail`"
var3="`show server inventory expand`"
var4="`show service-profile detail expand`"  
"""if help=="1":
 file="tmp/"+path+"/"+"A"+"/sam_techsupportinfo";
else :
  file=cwd+"/tmp/"+path+"/"+"A"+"/sam_techsupportinfo";"""

file=url+"/"+path+"/"+"A"+"/sam_techsupportinfo";

if(os.path.exists(file)):
  print " " 
else :
  """if help==1:
   file="tmp/"+path+"/"+"B"+"/sam_techsupportinfo";
  else:
   file=cwd+"/tmp/"+path+"/"+"B"+"/sam_techsupportinfo";"""
  file=url+"/"+path+"/"+"B"+"/sam_techsupportinfo";
if os.path.exists(file):
      countchassis=0
      fp=open(file,"r");
      for line in fp:
          if line.startswith("DME_META_ERROR"):
                   print"Error in SAM_TECHSUPPORT FILE"	
                   BREAK;
          if var1 in line:
             line=line.rstrip('\n');
             chassis=[]
             for line in fp:
                  if line.startswith('`show'):
                    break;
                  if line.startswith('Chassis '):
                      chasno= line[-3:-2]
                      countchassis=countchassis+1;
                      chassis.append(chasno) 


      
      fp.close()  
      
       


    
         
      if countchassis==0:
       count=0
       sum=0
       fp=open(file,"r")
       for line in fp:
            if "show server inventory expand" in line:
                for line in fp:
                     sum=sum+1
                     if line.startswith("`show"):
                        if sum==1:
                         count=1;
                         break;
       fp.close();
       if count==1:
          print"Error in sam_techsupportinfo"
      
       if count==0: 
         
         direct={}
         fp=open(file,"r")
         for line in fp:
                 if "show server inventory expand" in line :
                     for line in fp:
                             if "Server " in line:
                                  direct[line]=[]
                                  temp=line
                                  for line in fp:
                                        if "Model" in line:
                                             direct[temp].append(line)
                                        if "Vendor" in line:
                                             direct[temp].append(line)
                                        if "Serial (SN)" in line:
                                             direct[temp].append(line)
                                        if "Product Name" in line:
                                             direct[temp].append(line)
                                        if "PID" in line :
                                             direct[temp].append(line)
                                        if "Effective Memory" in line:
                                             direct[temp].append(line)
                                        if "Cores" in line:
                                             direct[temp].append(line)
                                        if "Adapters" in line:
                                             direct[temp].append(line)
                                        if "Bios:" in line:
                                                  break;
                          
                             if line.startswith("`show"):
                                   break; 
         fp.close();
         fp=open(file,"r");
         for line in fp:
              if"show server status detail" in line:
                  for line in fp:
                      if "Server " in line:
                         temp=line
                         for line in fp:
                              if "Availability" in line:
                                     direct[temp].append(line)
                              if "Admin State" in line:
                                     direct[temp].append(line)
                              if "Overall Status" in line:
                                     direct[temp].append(line)
                              if line=="\n":
                                    break;
                      if line.startswith("`show"):
                          break;
         fp.close();
         clilist={} 
         
         trows=["Model" , "Vendor" , "Serial" , "Product Name" , "PID" , "Memory" , "Cores","Adapters", "Avalability" ,"Admin State" ,"Overall Status"]
         for key in direct:
           i=0
           clilist[key]={}
           for item in trows:
              
              clilist[key][item]=direct[key][i]
              i=i+1
         if clivar!="1":


               pprint.pprint( clilist)
         if clivar=="1":
          print"<table id= 'customers'><tr><th></th>" 
          for key in direct:
           print"<th>"
           print key
           print"</th>"
          print"</tr>"
          for i in range(11):
           print"<tr>"
           print"<td>"
           print trows[i]
           print"</td>"
           for key in direct:
             print"<td>"
             print direct[key][i]
             print"</td>"
           print"</tr>"
   
      fp=open(file,"r")
      tenp=0
      for line in fp:
         
         if "`show chassis inventory detail" in line:
                 for line in fp:
                       if"Product Name" in line:
                           
                           tenp= line[-5:]
                           
                       if tenp == "4308\n":
                      
                          break;
                       if line.startswith('`show'):
                                break;
      fp.close();
      fp=open(file,"r")
      if tenp=="4308\n":
         
         NJCH=1
         pristia={ }
         list=[]
         list2=[]
         
         for line in fp:
             
              if "show server inventory expand" in line :
                      temp="Server "# +str(chassis[0])+ "/"
                      tempi= "Server " +str(chassis[1])+"/"
                      tempo=temp 
                      for line in fp:
                            if line.startswith("`show"):
                        
                                break; 
                            if temp in line or tempi in line:
                               temp=line
                              
                               if len(line)>12:
                                list2.append(temp)
                                for line in fp:
                                 if "Acknowledged Product Name" in line:
                                        list.append(line)
                                 if "Acknowledged PID" in line:
                                        list.append(line)
                                 if "Acknowledged VID" in line:
                                         list.append(line)
                                 if "Acknowledged Serial (SN)" in line:
                                         list.append(line)            
                                 if "Acknowledged Memory" in line:
                                         list.append(line)                
                                 if "Acknowledged Cores" in line:
                                         list.append(line)
                                 if"Adapters" in line:
                                         list.append(line)
                                 if line=="\n":
                                   break;
                                 if "Bios" in line:
                                         break;
                                pristia[temp]=list
                                list=[]
                                temp=tempo
         
         list3=["Product Name" , "PID" , "VID" , "Serial" ,"Memory" , "Cores", "Adapters"]
         print"<h1>NJ Chassis Servers</h1>"
         print"<table id='customers'><tr><th></th>"
         for item in list2:
          print"<th>"
          print item
          print"</th>"
         print"</tr>"
         for i in range(7):
          print"<tr><td>"
          print list3[i]
          print "</td>" 
          for key in pristia:
              print"<td>"
              print pristia[key][i]
              print"</td>"
          print"</tr>"           
         print"</table>"        
       
      fp.close();                            
      fp=open(file,"r");
      countserver=[]
   
      for line in fp:
              
             
                if var1 in line:
                           
                          line = line.rstrip('\n');
                          listia={ }
                          listib= { }
                         
                         
                          i = 0 
                          for line in fp:
                               
                               if i>=countchassis:
                                 break
                                 
                               if line.startswith('`show'):
                                
                                  break; 
                               tempu="Chassis " +str(chassis[i])
                               
                               if line.startswith(tempu):
                                   
                                            
                                  
                                   for line in fp:
                                     if "PSU" in line:
                                         
                                                               
                                         break;
                                     elif line.startswith("`show"):
                                        
                                                                              
                                         break;
                                     help="Server " + str(chassis[i]) +"/"
                                                                     
                                     if help  in line:
                                          
                                         count=count+1
                                         temp=line[-12:]
                                         for line in fp: 
                                           
                                           if "Acknowledged Product Name" in line:
                                                 
                                           
                                                 line=line[37:]    
                                                 lista.append(line)
                                           if "Equipped Serial" in line:
                                                 line=line[32:]
                                                 lista.append(line)
                                           if "Acknowledged Memory" in line:
                                                 line=line[36:]
                                                 lista.append(line)
                                           if "Acknowledged Cores" in line:
                                                 line=line[30:]
                                                 lista.append(line)
                                           if  line=='\n':
                                                  
                                                  break;
                                        

                                    
                                         listia[temp]=lista
                                         countserver.append(temp)      
                                         
                                                                         
                                         
                                         lista=[]
                                   maindic[chassis[i]]=listia
                                   listia={}
                                
                                  
                                  
                                   i=i+1     
                  
               
                numbserver= len(countserver)                    
                
                if var3 in line:
                           
                       j=0 
                       for line in fp:
                              
                                  
                              if j>=countchassis:
                                             
                                break;
                              if line.startswith('`show'):
                            
                                                                        
                                  break; 
                              tempu= "Server "+str(chassis[j])+"/"
                              
                              number=0
                             
                              if line.startswith(tempu):
                                 
                                 
                                 hello=0
                                 temp=line
                                 count=0
                                 list=[]
                                 
                                 count=0
                                 for line in fp:
                                   
                                   if "Adapter" in line and  "PID" in line and "Vendor" in line and "Serial" in line:
                                          
                                         count=count+1
                                         
                                         list=[]
                                         if  j >=countchassis:
                                                   break;

                                         maindic[chassis[j]][temp].append(list)
                                         
                                         listi=[]
                                         
                                         
                                         for line in fp:
                                           
                                           if"---" in line:
                                              number=number+1
                                              continue
                                           elif line=='\n':
                                              break
                                           else:
                                                 
                                              maindic[chassis[j]][temp][4].append(line) 
                                   k=j+1
                                                               
                                   if k<countchassis+1:
                                     
                                     tring="Server "+str(chassis[j])+"/"
                                     tring1="Servers "
                                     
                                   temp3="Server "+str(chassis[j])+"/"
                                   if countchassis>hello+1 and temp3 in temp:
                                      
                                     tring1= "Server "+str(chassis[j+1])+"/"   
                                                                          
                                   
                                   if line.startswith(tring) or line.startswith(tring1):
                                       
                                       if count==0:
                                         number=number+1
                                         lol=[]
                                         maindic[chassis[j]][temp].append(lol)
                                       if tring1 in line and countchassis>1:
                                             
                                             
                                             j=j+1
                                             hello=hello+1
                                      
                                       temp=line            
                                       if temp==countserver[numbserver-1]:
                                          maindic[chassis[j]][countserver[numbserver-1]].append([ ])
                                          break;
                                       count=0 
                                    
                                   else:
                                      continue;
                             
                              j=j+1    
                  
                                                           
                     
                                                                
                if var2 in line:
                       k=0
                      
                       count1=0
                       
                       for line in fp:
                              
                              if k>=countchassis:
                                      break;
                              if line.startswith('`show'):
                               
                                break;
                              tring="Server "+str(chassis[k])+"/"
                              
                                                      
                              if tring  in  line:
                                      temp=line[-12:]
                                                                   
                                      if "Server "  in temp:
                                       lista=[];
                                      
                                     
                                       for line in fp:
                                            if "Availability" in line:
                                               line=line[16:]
                                                                                              
                                               lista.append(line)
                                            if "Admin State" in line:
                                               
                                               line=line[15:]
                                               lista.append(line)
                                            if "Overall Status" in line:
                                             
                                               line=line[18:]
                                               lista.append(line)
                                            
                                            if line=='\n' :
                                               break;
                                     
                                      
                                      
                                       count1=count1+1
                          
                                       maindic[chassis[k]][temp].append(lista)
                                      
                                      
                              if count1>=len(maindic[chassis[k]]):
                                   k=k+1  
                                    
                                   
                                   count1=0      
                                      
                messi=0                                   
                if var4 in line:
                       
                       messi=messi+1
                       temp3=[]
                       n=0
                       for line in fp:
                            list=[]
                             
                            if line.startswith('`show'):
                                 
            		         break;
                            if ("Service Profile Name:") in line:
                               
                             
                              
                               temp2=line
                               for line in fp:
                                    
                                   
                                    if '   Server:' in line:
                                        line1=line.split(":")
                                        
                                        if len(line1[1])<2:
                                               break; 
                                        temp=line;
                                        temp1=temp[-4:]
                                 
                                        var =temp1[0:1]
                                        tempu=str(chassis[n])+"/"
                                       
                                        
                                        
                                          
                                        temp1=temp1.strip('\n')
                                        temp1="Server "+temp1+":"+"\n"
                                        temp3.append(temp1)                  
                                                
                                    if 'Power State' in line:
                                       list.append(line[-3:])
                                       list.append(temp2[-6:])
                                    if 'Op State' in line:
                                       list.append(line[-3:])
                                    if 'Association' in line:
                                       list.append(line[-11:])
                                   
                                    if line== "\n":
                                       break;
                                   
                               
                               if len(line1[1])>1:
                               
                                maindic[var][temp1].append(list)
                                
                                                           
                                        
                       for x in range(countchassis):
                               xms=str(x+1)
                               for key in maindic[xms]:
                                 if key in temp3:
                                   print " "
                                 else :
                                  maindic[xms][key].append( " ")
            
          
                          
      fp.close();
      listo1=["Serialno", "product name" , "memory" ,"Cores" ,"Availability", "Admin State" , "Overall state","Association","Power State","Service profile Name", "Op State"];

      
      if clivar!="1":
           for key in maindic:
               temp=key
               clidic[temp]={}
               for key1 in maindic[temp]:
                  k=0
                  w=0
                  clidic[temp][key1]={}
                  for i in range(11):
                         if i <=3:
                          clidic[temp][key1][listo1[i]]=maindic[temp][key1][i]
                         if i>3 and i <=6:
                          
                          clidic[temp][key1][listo1[i]]=maindic[temp][key1][5][k]
                          k=k+1
                         if i>6 and i<=10:
                          if len(maindic[temp][key1][6])>2:
                           clidic[temp][key1][listo1[i]]=maindic[temp][key1][6][w]
                           w=w+1
                          else:
                           clidic[temp][key1][listo1[i]]=" "


           pprint.pprint(clidic)             
      if clivar=="1":     
       
       
      
       keys=maindic.keys()
      
 
       if NJCH==1:
         
         countchassis=countchassis-1
       for o in range(countchassis):
       
        if len(maindic[keys[0]])>1:
          print "<h1>"
          print "Chassis"+keys[o]+" Servers"
          print "</h1>"
        print " <table id='customers'><tr><th>  </th>"
        lolp=keys[o]
    
        for h in maindic[lolp]:
         
         print"<th>%s"%h
         print"</th>"
        print"</tr>"
    


        listo=["Serialno", "product name" , "memory" ,"Cores" ,"Adapter Number" ,"Adapter PID", "Adapter Vendor" , "Adapter serial" , "Adapter Overall Status","Availability", "Admin State" , "Overall state","Association","Power State","Service profile Name", "Op State"]; 
      #print"<tr><th>Serial no  <br><br></th></tr><tr><th>Product Name   </th></tr><tr><th>Memory    </th></tr><tr><th>Cores   </th></tr><tr><th>Availability   </th></tr><tr><th>State   </th></tr><tr><th>Overall state</th> </tr>"
        count=0
        sum=0
        sum1=0
        j=0
        k=0
        z=0
        y=0
      
        d=0
        
        for key in maindic:
          for key1 in maindic[key]:  
             for i in range(4):
                
                
                if ":" in  str(maindic[key][key1][i]):
                    
           
                     maindic[key][key1][i]=  str(maindic[key][key1][i]).replace(":","")
             for i in range(3):
              if ":" in str(maindic[key][key1][5][i]):
                  
                  maindic[key][key1][5][i]=str(maindic[key][key1][5][i]).replace(":","")
       
        for key in maindic[lolp]:
           length=len(maindic[lolp][key][4])
          
           
           if length==0:
              newlist=[]
             

           else: 
              newlist=[]
              newlist1=[]
              for i in range(length):
                  #newlist=[]      
                  #newlist1=[]
                   
                  newlist= maindic[lolp][key][4][i].split()
                  length1=len(newlist)
                  
                   
                               
                  if length1!=5:          
                   for k in range(length1):

                     if k==2:
                       m=k  
                       str1=""
                       while (m < length1-2):
                          str1=str1+str(newlist[m])
                          m=m+1
                       newlist1.append(str1)
                     elif k>2 and k<length1-2  :
                       continue                      
                     else:
                       
                       newlist1.append(newlist[k])
                     maindic[lolp][key][4][i]=newlist1
                     #if len(newlist1[0]) > 2:
                      # print "koko"
                       #maindic[lolp][key][4][i-1].extend(newlist1)     
                  if length1==5:
                      
                      for k in range(length1):
                        if k==0:
                          
                          p=k
                          str2=""
                          while(p<length1-2):
                            str2=str2+str(newlist[p])
                            p=p+1
                          newlist1.append(str2)
                        elif k>=length1-2:
                          newlist1.append(newlist[k])
                      maindic[lolp][key][4][i-1]=newlist1
                      maindic[lolp][key][4][i]=[]
                    
        #if len(maindic['1']['Server 1/3:\n'])==7:
        var5='Server ' +keys[o] +'/3:\n'
        if len(maindic[keys[o]][var5])==7:
           rang=16
        else:
            rang=12
       
        
        for i in range(rang):
 
         
           

         print "<tr>"
         for item in listo:
             print'<td>%s'%listo[count]
             print"</td>"
             count=count+1
             break;
         if i>=4 and i <=8:
            for key in maindic[lolp]:
             
               num= len(maindic[lolp][key][4])
              
               
               if num == 0 :
                  print" <td> </td>"
               elif num==1:
                  print '<td>%s'%maindic[lolp][key][4][0][y]
                  print '</td>'
               elif num==2:
                  print '<td>%s'%maindic[lolp][key][4][0][y]
                  print '</td>'

               else:
                 t=""
                 for d in range(num):
                       if len(maindic[lolp][key][4][d])<7:
                           #print len(maindic[lolp][key][4][d])
                           #rint maindic[lolp][key][4][d]
                           continue
                       else:
   
                          t= t+ maindic[lolp][key][4][d][y] + ","    
                          print t 
                 print '<td>%s'%t
                 print'</td>'
            y=y+1
         if i>= 9 and i <=11 :
             
             for key in maindic[lolp]:
                
                print'<td>%s'%maindic[lolp][key][5][sum]
               
                print'</td>'
                                
             sum=sum+1
            
         elif i>=12 and i <=15:
                
              
              for key in maindic[lolp]:
                 
                  if len(maindic[lolp][key][6])>2:
                     
                   
                     print'<td>%s'%maindic[lolp][key][6][z]
                  
                     print'</td>'



                  else:
                    print '<td> </td>'

              
              z=z+1

         elif i <4 :
             
             for key in maindic[lolp]:
                 
                 print'<td>%s'%maindic[lolp][key][i]
                 print'</td>'
         print"</tr>"



        print " </table>"
      
       fp= open(file,"r")
      
       listqq={}
       
     
       for line in fp:
        
        if var1 in line:
            
            cardno=0
            for line in fp:
                if line.startswith("Chassis"):
                    p=line
                    temp=p
                if line.startswith('`show'):
                          
                           break;
                if line.startswith(temp):
                   mainiodic[temp]={}         
                   
                   for line in fp:
                    
                    if "Storage VD Membership" in line or "Storage Local Disk: " in line:
                             break;
                    if "Switch IOCard " in line or "IOCard" in line:
                     
                     cardno=cardno+1
                     listq=[]
                     listq.append(line)
                     tempu=line      
                     for line in fp:
                        if "Side" in line:
                           listq.append(line)
                        if "Fabric ID" in line:
                           listq.append(line)
                        if "Product Name" in line:
                          listq.append(line)
                        if "Vendor:" in line:
                         listq.append(line)
                        if "Serial (SN)" in line:
                         listq.append(line)
                        if line== "\n":
                              break;
                  
                     if cardno<=2:
                       
                       
                       cardno=0
                       
                       mainiodic[temp][tempu]=listq
                       
                      
                       
                       
                    
                  
       fp.close()  
           
       for key1  in mainiodic:
        c=0
        if mainiodic[key1]!={ } :
         print"<h1>"
         print key1
         print "IOCards"
         print "</h1>"
         
         c=c+1
         print"</h1>" 
         print"<table id='customers'><tr>"
         print "<th>  </th>"
         for key in mainiodic[key1]:
            print "<th>%s"%key
            print"</th>"
         lo=0
         print"</tr>"
         listb=["IOCard No " , " Side" , "Fabric ID" , "Product Name" , "Vendor" , " Serial numnber" ]
         for i in range(6):
          print"<tr>"
          for item in listb:
             print "<td>%s"%listb[lo]
             print"</td>" 
             lo=lo+1
             break;    
          for key in mainiodic[key1]:
             print "<td>%s"%mainiodic[key1][key][i]
             print"</td>"
 
          print"</tr>"

         print"</table>"
else:
  print(" ")
