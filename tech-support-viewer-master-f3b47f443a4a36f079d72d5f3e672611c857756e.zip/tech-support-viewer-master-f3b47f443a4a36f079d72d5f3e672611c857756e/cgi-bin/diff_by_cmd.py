#!/usr/bin/python 
#!/usr/bin/env python
import difflib
#from difflib_data import *
import cgi 
import os 
import time 
import sys
import shlex
print "Content-Type: text/plain;charset=utf-8\n"
form = cgi.FieldStorage() 
#count = form.getvalue("count") 
path = form.getvalue("id")
path1= form.getvalue("id1")
cmd=form.getvalue("commands")
cmd=str(cmd)
command=cmd.split(',') 

#path = str(path) 
#count=str(count)


file1 = "tmp/"+path+"/A/sw_techsupportinfo"; 
file2= "tmp/"+path1+"/A/sw_techsupportinfo";


f1=open(file1,"r");
f2=open(file2,"r");

l1=f1.readlines();
l2=f2.readlines();
flag=0

content1=""
content2=""
d=difflib.Differ();
for i in range(len(command)):
	content1=""
	flag=0
	for j in range(len(l1)):
		if l1[j].startswith(command[i]) or flag==1:
			#print command[i]
			j=j+1;
			flag=1
			if '`show' in l1[j]:
				break;
			content1=content1+l1[j];
	content2=""
	if flag==0:
		print command[i]+" is not a Valid Command"
		continue
		
        flag=0
        for j in range(len(l2)):
                if l2[j].startswith(command[i]) or flag==1:
                        #print command[i]
                        j=j+1;
                        flag=1
                        if '`show' in l2[j]:
                                break;
                        content2=content2+ l2[j];
	
	diff=difflib.context_diff(content1.splitlines(),content2.splitlines());
	d= '\n'.join(diff)
	print "\n"
	print command[i]
	if d == "":
		print "No diff found for this command"
		continue
	print """<html><body><b>"""
	 
	print """</b></body></html>"""
	print d			
	
