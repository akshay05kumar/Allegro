#!/usr/bin/python 
#!/usr/bin/env python
import difflib
#from difflib_data import *
import cgi 
import os 
import time 
import sys
import shlex
print "Content-Type: text/plain;charset=utf-8\n"
form = cgi.FieldStorage() 
#count = form.getvalue("count") 
path = form.getvalue("id")
path1=form.getvalue("id1") 
#path = str(path) 
#count=str(count)

print "RUNTIME CHANGES"
print "\n========================================================================================"
file1 = "tmp/"+path+"/A/sw_techsupportinfo"; 
file2= "tmp/"+path1+"/A/sw_techsupportinfo";
command=['`show interface mgmt0`','`show interface fex-fabric`','`show interface counters errors`','`show interface brief`','`show interface`','`show interface switchport`','`show interface trunk`','`show interface counters detailed all`','`show interface priority-flow-control`','`show interface flowcontrol`','`show interface virtual summary`','`show interface virtual status'];

f1=open(file1,"r");
if os.path.exists(file2):
	f2=open(file2,"r");
else:
	print "Second tech-support file not found"
	sys.exit()

l1=f1.readlines();
l2=f2.readlines();
flag=0

content1=""
content2=""
d=difflib.Differ();
for i in range(len(command)):
	content1=""
	flag=0
	for j in range(len(l1)):
		if l1[j].startswith(command[i]) or flag==1:
			#print command[i]
			j=j+1;
			flag=1
			if '`show' in l1[j]:
				break;
			content1=content1+l1[j];
	content2=""
        flag=0
        for j in range(len(l2)):
                if l2[j].startswith(command[i]) or flag==1:
                        #print command[i]
                        j=j+1;
                        flag=1
                        if '`show' in l2[j]:
                                break;
                        content2=content2+ l2[j];
	
	diff=difflib.context_diff(content1.splitlines(),content2.splitlines());
	d= '\n'.join(diff)
	if d == "":
		continue
	print """<html><body><b>"""
	print command[i] 
	print """</b></body></html>"""
	print d			
	print "\n++++++++++++++++++++++++++++++++++++++++++++++++"
	

print "\n========================================================================================"
command=['`show running-config | grep -v username`','`show running-config switch-profile`','`show running-config port-security all`','`show running-config netflow`'];
print "RUNNING CONFIGURATION CHANGES"
print "\n"

flag=0

content1=""
content2=""
d=difflib.Differ();
for i in range(len(command)):
        content1=""
        flag=0
        for j in range(len(l1)):
                if l1[j].startswith(command[i]) or flag==1:
                        #print command[i]
                        j=j+1;
                        flag=1
                        if '`show' in l1[j]:
                                break;
                        content1=content1+l1[j];
        content2=""
        flag=0
        for j in range(len(l2)):
                if l2[j].startswith(command[i]) or flag==1:
                        #print command[i]
                        j=j+1;
                        flag=1
                        if '`show' in l2[j]:
                                break;
                        content2=content2+ l2[j];

        diff=difflib.context_diff(content1.splitlines(),content2.splitlines());
	
        d= '\n'.join(diff)
        if d == "":
                continue
        print """<html><body><b>"""
        print command[i]
        print """</b></body></html>"""
        print d
        print "\n+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"


