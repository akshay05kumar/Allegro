#!/usr/bin/python
#!/usr/bin/env python
import os
import shlex
import cgi
import sys
import datetime
import time
import string

print "Content-Type: text/plain;charset=utf-8\n"

form = cgi.FieldStorage()
id = form.getvalue("id")
name = form.getvalue("path")
mez = form.getvalue("mez")

t_file = "tmp/"+id+"AA/"+mez+"/"+name

if os.path.isfile(t_file):

        os.system("cd tmp/"+id+"AA/"+mez+"; mkdir obfl; cd obfl; tar -xzvf ../"+name +" > /dev/null")
        directory = "tmp/"+id+"AA/"+mez+"/obfl/obfl"
        for file in os.listdir(directory):
		if file=="syslog":
			print file

		if file.endswith(".gz")!=0:
			name = file.split(".")[0]+"."+file.split(".")[1]
			print name
			# unzip : gzip -d file.gz
			os.system("cd tmp/"+id+"AA/"+mez+"/obfl/obfl; gzip -d "+file+"")
