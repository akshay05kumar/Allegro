#!/usr/bin/python
#!/usr/bin/env python



import os
import cgi
import sys






import pprint 


from property import url

listo=[]
VLAN1="`show vlan"
form=cgi.FieldStorage()
side=form.getvalue("side")
side=str(side)
command=form.getvalue("command")
path=form.getvalue("id")
clivar=""
clivar=form.getvalue("count")
path=str(path)
if clivar=="1":
  print "Content-Type: text/plain;charset=utf-8\n"

if clivar !="1":
    
   path=str(sys.argv[2])
  
     
def scaling(side):
 cwd=os.getcwd()
 """if clivar!="1":
    
     file=cwd+"/tmp/"+path+"/"+side+"/sw_techsupportinfo";
 else:
  file = "tmp/"+path+"/"+side+"/sw_techsupportinfo";
 """ 
 file = url+"/"+path+"/"+side+"/sw_techsupportinfo";



 if os.path.exists(file):
   fp=open(file,"r")

   for line in fp:
          
          if VLAN1 in line:
              
              for line in fp:
                 if "VLAN" in line and "Type" in line:
                         
                         vlancount=0
                         for line in fp:
                              vlancount=vlancount+1
                              if line=="\n":
                               break;
                              if "Primary" in line:
                               break;                           
                        
                         listo.append(vlancount-3)
                 if line.startswith("`show"):
                                    
                        break;
                 
   fp.close();
   fp=open(file,"r")
   maccount=0
   for line in fp:
             if "show mac address-table" in line:
                 for line in fp:
                          if "VLAN" in line and "MAC Address" in line:
                              for line in fp:
                                   maccount=maccount+1
                                   if line=='\n':
                                        break;
                              
                              listo.append(maccount-3)
                          if line.startswith('`show'):
                                    break;
   fp.close(); 
   fp=open(file,"r")
   count=0
   vethcount=0
   for line in fp:
             if "show interface brief" in line:
                 
                 for line in fp:
                          if "VLAN" in line and "Vethernet" in line:
                            if count<1:   
                              for line in fp:
                                   
                          
                                   vethcount=vethcount+1
                                   if line=='\n':
                                        break;
                              count=count+1
                              listo.append(vethcount-2)
                         
                          if line.startswith('`show'):
                                    if vethcount<=0:
                                       listo.append(0)
                                    break;

   fp.close();
   fp=open(file,"r")
   groupcount=0
   for line in fp:
             if "show ip igmp snooping groups detail" in line:

                 for line in fp:
                         
                          if "Group Address" in line:
                              
                              for line in fp:


                                   groupcount=groupcount+1
                                   if line=='\n':
                                        break;
                              
                          if line.startswith('`show'):
                                    
                                    #listo.append(groupcount)
                                    break;
   listo.append(0)
   fp.close();
   
listia={}
side="A"
scaling(side)

listia[side]=listo
listo=[]



side="B"
scaling(side)
listia[side]=listo
cwd=os.getcwd()


"""if clivar=="1":
 file = "tmp/"+path+"/"+"A"+"/sam_techsupportinfo";
else:
 file = cwd+"/tmp/"+path+"/"+"A"+"/sam_techsupportinfo";
"""
file = url+"/"+path+"/"+"A"+"/sam_techsupportinfo";

if os.path.exists(file):
   
    print " "
else:
     file=url+"/"+path+"/"+"B"+"/sam_techsupportinfo";

     """if clivar=="1":
      file="tmp/"+path+"/"+"B"+"/sam_techsupportinfo";
     else:
      file = cwd+"/tmp/"+path+"/"+"B"+"/sam_techsupportinfo";"""
     #file="tmp/"+path+"/"+"B"+"/sam_techsupportinfo";

fp=open(file,"r")
for line in fp:
  if "scope fabric-interconnect a" in line:
        for line in fp:
            if "show vlan-port-count expand detail" in line:
                for line in fp:
                  if "Invalid" in line:
                      for l in range(3):
                         listia["A"].append(0)
                      break;   
                  
                  if "VLAN-Port Limit:" in line:
                      line1=line.split(":")
                      line2=line1[1] 
                                
                      listia["A"].append(line2[:-1])
                  if "Access VLAN-Port Count" in line:
                      temp=   line[-6:-1]
                      if ":" in temp:
                          temp1= temp.split(":")
                          listia["A"].append(temp1[1])

                      else:
                        listia["A"].append(line[-6:-1])
                  if "Border VLAN-Port Count" in line:
                       line1=line.split(":")
                       line2=line1[1]
                       listia["A"].append(line2[:-1])
                  if line.startswith("`show"):
                         break;

                break;  



  if "scope fabric-interconnect b" in line:
       for line in fp:
            if "show vlan-port-count expand detail" in line:
                for line in fp:
                                
                  if "VLAN-Port Limit:" in line:
                      line1=line.split(":")
                      line2=line1[1]
                      listia["B"].append(line2[:-1])
                  if "Access VLAN-Port Count" in line:
                      line1=line.split(":")
                      
                      line2=line1[1]
                      listia["B"].append(line2[:-1])
                  if "Border VLAN-Port Count" in line:
                       line1=line.split(":")
                       line2=line1[1]
                       listia["B"].append(line2[:-1])

                  if line.startswith("`show"):
                              break;
                break;  

list2=["VLAN count" ,"MAC count" , "VETH count", "IGMP count" ,"VLAN-PORT Limit" , "Access Vlan Port Count" , "Border Vlan Port Count"]
ristia={ }
ristia['A']={ }
ristia['B']={ } 
fp.close();
if clivar !="1":
 
 i=0
 sidel="A"
 for l in range(2):
   
    for item in list2:
    
      ristia[sidel][item]=listia[sidel][i]    
      i=i+1
    sidel="B"
    i=0
       




 pprint.pprint(ristia)
else:

 print "<table id=customers>"
 if len(listia["A"])>1:
  print "<tr><th> </th> <th>A</th>"  
 if len(listia["B"])>1:
 
   print"<th> B </th>" 
 print"</tr>"
 for i  in range(7):
    print "<tr><td>"
    print list2[i]
    print "</td>"
    for key in listia:
     if len(listia[key])>1:
        print"<td>"
        print listia[key][i]
        print"</td>"
    print"</tr>"
 print "</table>"
   
