import os
import sys


var1=os.getcwd();

#scriptpath="/home/harmehta/tech-support-viewer/cgi-bin"
scriptpath=var1+"/cgi-bin"
#url="/home/harmehta/tech-support-viewer/tmp"
url=var1+"/tmp"
#variable which helps to get to tech support files 
