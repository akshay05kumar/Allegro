#!/usr/bin/python
#!/usr/bin/env python
import os
import cgi

print "Content-Type: text/plain;charset=utf-8\n"
form = cgi.FieldStorage()
side = form.getvalue("side")
command = form.getvalue("command")
path = form.getvalue("id")
#path = form.getvalue("path") // get path from harsh
file = "tmp/"+path+"/"+side+"/sw_techsupportinfo";

if os.path.exists(file):
	fp = open(file,"r");
	for line in fp:
		if line.startswith('`show'):
			line = line.rstrip('\n')
			print(line)
else:
	print("")
