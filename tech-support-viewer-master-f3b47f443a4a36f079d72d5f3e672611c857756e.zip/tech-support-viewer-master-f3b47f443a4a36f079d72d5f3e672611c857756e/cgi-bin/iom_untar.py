#!/usr/bin/python 
#!/usr/bin/env python 
import os 
import shlex 
import cgi 
import sys 
import datetime 
import time 
import string

print "Content-Type: text/plain;charset=utf-8\n"
form = cgi.FieldStorage()
iom_path = form.getvalue("id")
tarfile = form.getvalue("path")

newpath = str(tarfile)
newpath = newpath.split(".")[0]

t_file = "tmp/"+iom_path+tarfile

if os.path.isfile(t_file):
	if os.path.exists("tmp/"+iom_path+"AA"):
	        os.system("cd tmp/"+iom_path+"AA; tar -xzvf ../"+tarfile +" > /dev/null")
	else:
		os.system("cd tmp/"+iom_path+"; mkdir AA; cd AA; tar -xzvf ../"+tarfile +" > /dev/null")
	directory = "tmp/"+iom_path+"AA/"+newpath
	for file in os.listdir(directory):
		if file.endswith(".tar.gz")!=0 and file.find("obfl")==0:
			print file
	
