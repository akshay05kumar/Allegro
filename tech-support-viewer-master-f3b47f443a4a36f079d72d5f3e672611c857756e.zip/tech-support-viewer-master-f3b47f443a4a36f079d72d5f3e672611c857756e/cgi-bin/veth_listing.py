#!/usr/bin/python
#!/usr/bin/env python
import os
import sys
import cgi
from property import url
import shlex
from itertools import islice
import time

form = cgi.FieldStorage()
path=form.getvalue("id")

print "Content-Type: text/plain;charset=utf-8\n"

text1 = "`show interface virtual status `"
text11 = '`show interface virtual status`'
text2 = "`show interface brief`"
file1 = url+"/"+ path + "/A/sw_techsupportinfo";
file2 = url+"/"+ path + "/B/sw_techsupportinfo";

veth_list = []
veth_name = []
if os.path.exists(file1):
        fp = open(file1,"r")
        for line in fp:
		if text2 in line:
                        line = line.rstrip('\n');
                        for line in fp:
                                if line.startswith('`show'):
                                        break;
                                line = line.replace("<", " ")
                                line = line.replace(">", " ")
                                words = line.split()
				
                                if (len(words)>0) and (words[0].startswith("Veth")) and (words[0] not in veth_name):
				
					if 'up' in line:
						veth_name.append(words[0])
                                                veth_list.append(words[0]+'- up A')
					if 'down' in line:
						veth_name.append(words[0])
						veth_list.append(words[0]+'- down A')
                                               
	
        fp.close();

if os.path.exists(file2):
        fp = open(file2,"r")
        for line in fp:
                if text2 in line:
                        line = line.rstrip('\n');
                        for line in fp:
                                if line.startswith('`show'):
                                        break;
                                line = line.replace("<", " ")
                                line = line.replace(">", " ")
                                words = line.split()

                                if (len(words)>0) and (words[0].startswith("Veth")) and (words[0] not in veth_name):

                                        if 'up' in line:
                                                veth_name.append(words[0])
                                                veth_list.append(words[0]+'- up B')
                                        if 'down' in line:
                                                veth_name.append(words[0])
                                                veth_list.append(words[0]+'- down B')

        fp.close();

i = 0
for i in range(len(veth_list)):
	print veth_list[i]
if veth_list == []:
	print "NO VETH FOUND"
