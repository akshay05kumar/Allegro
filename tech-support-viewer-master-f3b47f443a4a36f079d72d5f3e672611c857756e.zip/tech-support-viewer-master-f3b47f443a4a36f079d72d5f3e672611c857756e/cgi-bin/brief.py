#!/usr/bin/python
#!/usr/bin/env python
import cgi
import os
import time

form = cgi.FieldStorage()
side = form.getvalue("side")
path = form.getvalue("id")
path = str(path)
text = "`show interface brief`"
type = "command"
file = "tmp/"+path+"/"+side+"/sw_techsupportinfo";

if os.path.exists(file):
	fp = open(file,"r");
	for line in fp:
		if text in line:
			line = line.rstrip('\n');
			for line in fp:
					if line.startswith('`show'):
						break;
					# elif line.startswith('Eth'):
					line1 = line.rstrip().split(' ')
					if len(line1[0]) < 20:
						print line1[0]
	fp.close();
else:
	print(" ")

