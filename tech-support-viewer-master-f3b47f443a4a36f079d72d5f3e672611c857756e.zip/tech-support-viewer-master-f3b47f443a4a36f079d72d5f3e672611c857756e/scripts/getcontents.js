// SERVER_LOCATION MUST be with trailing '/'
var SERVER_LOCATION = "/cgi-bin/";

// File Names
var COMMAND_CONTENT = "command_content.py"
var BRIEF_INFO = "brief_info.py"

self.onmessage=function(event) {
	var id =event.data.id;
	id=id.replace("/", '%2F');
	id=id.substring(0,id.length-1);
	id=id.replace("/","%2F");
	
	var text=event.data.text;
        text=text.replace('/','^')
        text=text.replace('/','^')
        text=text.replace('/','^')
        text=text.replace('/','^')
        text=text.replace('/','^')
        text=text.replace('/','^')
        text=text.replace('/','^')
        text=text.replace('/','^')

	var type=event.data.type;
	var side=event.data.side;
	var page=event.data.page;
	page=parseInt(page);
	side=side.toUpperCase();
        
     	var filter = event.data.filter;
	var mez_value = event.data.mez_value;

	if (text.startsWith('`')||( type== "file")) {	
		var xhttp = new XMLHttpRequest();
		xhttp.open("get", SERVER_LOCATION + COMMAND_CONTENT + "?side="+side+"&type="+type+"&text="+text+"&id="+id+"&filter="+filter+"&mez_value="+mez_value+"&page="+page+"%2F", true);
		xhttp.send();
		xhttp.onreadystatechange = function() {
			data1=null;
			if (xhttp.readyState==4 && xhttp.status==200) {
				data1=xhttp.responseText;
                                                       
				if (data1 != null) {
					var data2=JSON.stringify(data1);
					var data3=data2.slice(-4);
					var data4=data3[0];
					data4=parseInt(data4);
					self.postMessage(data1);
				}
			}
		}
	} else {
		var xhttp = new XMLHttpRequest();
		text=text.replace('/','^');
		text=text.replace('/','^');
		xhttp.open("get", SERVER_LOCATION + BRIEF_INFO + "?side="+side+"&type="+type+"&text="+text+"&id="+id+"&page="+page+"%2F", true);
		xhttp.send();
		xhttp.onreadystatechange = function() {
			data1=null;
			if (xhttp.readyState==4 && xhttp.status==200) {
				data1=xhttp.responseText;
				self.postMessage(data1);
			}
		}
	}
}
