// SERVER_LOCATION MUST be with trailing '/' var SERVER_LOCATION = "cgi-bin/";
var SECTECH="sectech.py"
// File Names
var client_id="";
filename="";
var DIFF="difference.py" ;
var IOMCOMMANDS="iomcmd.py";
var IOMFILES = "iomfiles.py";
var CMP_CMD="diff_by_cmd.py"; 
var FILES = "files.py"; var COMMANDS = "commands.py"; var COMMAND_CONTENT = "command_content.py" ; var INVENTORY = "inventory.py";
 var CREATE_WS = "create_ws.py";
 var SYSTEM_HEALTH = "health.py";
 var BRIEF="brief.py";
 var SERVER_CHANGE="server_change.py" ;
var GET_SCALING= "get_scaling.py" ;
var GET_INVENTORY="get_inventory.py"; 
var GET_SUGGESTIONS="getsuggetions.py"; 
var GET_SUGGESTIONSBUG="getsuggetionsbug.py";
var NEWFILES = "newfiles.py";
var IOM_ID;
var OPENGROC_SERVER = "http://savbu-ucs-bld30:9100/"; var BRANCH = "ucs_integ"; var CLIENT_ID; var SUCCESS = 0; var FAILURE = 1;
var FILEUP="fileup.py";

var IOM_UNTAR = "iom_untar.py";
var IOM_UNTAR_INNER = "iom_untar_inner.py";
var VETH_LISTING = "veth_listing.py";
var VETH_DATA = "veth_data.py";
var NEW_DATA = "newfile.py";
var UPLOADVAR=1;
// Files | Commands List
var a_command_list			= "";
var a_file_list				= "";
var b_command_list			= "";
var b_file_list				= "";
var a_brief_list			= "";
var a_iom_lists="";
var b_iom_lists="";
var sys_log_list = "";
var key1 =  "";
var key2 = "";
var mez_value = "";
// Search
var search_terms			= [];
var search_terms_color		= [
	["#0DCFB5","#000"], ["#22246B","#fff"], ["#2C8A16","#000"], ["#AFC50B","#000"], ["#918504","#fff"],
	["#303202","#fff"], ["#F2E5D7","#000"], ["#AA6924","#fff"], ["#E1F03E","#000"], ["#4FEAFF","#000"],
	["#FD656C","#000"], ["#BD3632","#000"], ["#89E0F8","#000"], ["#5F947A","#fff"], ["#C0D5E9","#000"]];
var search_terms_color_count = 0;
var open_tabs = [];
var ot = 0;

// Tab Functionalitvar
tabTemplate = "<li class='tab_title'><a href='#{href}' title='#{title}'>#{label}</a> <span class='ui-icon ui-icon-close' role='presentation'>Remove Tab</span></li>";
var tabCounter = 0;
var tab_count = 0;
var tabs;
var tabs_updated = [];	// Maintains a list of tabs that whose contents are updated, so that parse_tab_data is not called multiple times.
var tabs_content = [];	// Maintains all raw form of tab content

// 'Jan 5 08:23:07 2015' || '2015 Jan 5 08:23:07'
var RE_TIME = new RegExp("((\\d){4}\\s)?(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)(\\s){1,2}(\\d){1,2}\\s\\d{2}:\\d{2}:\\d{2}(\\s(\\d){4})?", "gi");

// Call windowResize everytime the browser is resized
$(window).resize(windowResize);

function onload() {
	// Dont know why, but windowResize needs to be called twice.
	windowResize();
	windowResize();

	// Tab Functionality
	$("#sortable").sortable();
	$("#sortable").disableSelection();
	tabs = $("#tabs").tabs();
	$("#tabs").tabs({
		activate: function(event, ui) {update_active_tab();}
	});
	// close icon: removing the tab on click
	tabs.delegate("span.ui-icon-close", "click", function() {
		var panelId = $(this).closest("li").remove().attr("aria-controls");
		$("#" + panelId).remove();		
		// Delete saved raw tab_content
		//delete tabs_content[panelId];
		tabs_content[panelId] = "";
		tabs.tabs("refresh");
		windowResize();
		tab_count--;		
	});

	// Listen for "Enter" key on search_text
	$("#search_text").keyup(function (e) {
		if (e.keyCode == 13) {
			ret = add_to_search_terms($('#search_text').val());
			if (ret === SUCCESS)
				$('#search_text').val("");
		}
	});

	// onFocusOut for .datetime divs
	$('.datetime').focusout(function() {
			// Update content of active tab
			tabs_updated = [];	// Reset list of updated tabs.
			update_active_tab();
	});

	// Dialog Box for getting tech-support path
	$(function() {
		$("#dialog").dialog({
			closeOnEscape: false,
			width:700,
			resizable: false,
			dialogClass: 'no-close',
			buttons: {
				"Submit": send_techsupport,
			}
		});
	});

	// Class time Draggable
}

$(function() {
	$(".time").draggable({revert:true, helper:"clone"});
});

function getcmddiff(){
  var commands=$('#compare_commands').val();
	if (client_id === "")
		alert('Need one more tech support file');
	else{
  if (commands==""){
      alert("enter commands first");}
  else {  
       $.get(SERVER_LOCATION+CMP_CMD, {id:CLIENT_ID,id1:client_id, commands:commands}, function(data, status) {
                 addTab("COMMANDS DIFFERENCES", data);
      });
      }
	}
}

function filehandle()
{
    var x = document.getElementById("myFile");
    var txt = "";
    if ('files' in x) {
        if (x.files.length == 0) {
            console.log( "Select one or more files.");
        } 
         else {
            for (var i = 0; i < x.files.length; i++) {
                //console.log("<br><strong>" + (i+1) + ". file</strong><br>");
                var file = x.files[i];
                if ('name' in file) {
                    console.log(file.name);
                }
                if ('size' in file) {
                    console.log( file.size);
                    console.log( x.value);
                }
            }
        }
    } 
}

function myFunction() {
UPLOADVAR=0;
var xhr = new XMLHttpRequest();
var fd = new FormData();
var obj =document.getElementById("myFile1").files[0];
fd.append( 'file', obj );
filename=obj.name;
xhr.open( 'POST',SERVER_LOCATION+FILEUP, true );
xhr.send( fd );
}

function getsecondtech() {
var second  = prompt("Please enter your second techsupport path", "Second techpath");
var user = $('#tech_support_username').val();
$.get(SERVER_LOCATION+SECTECH, {user: user, second: second , count:"1"}, function(data, status) {
                client_id=data;
	});
}

// Send Tech-support location
function send_techsupport() {
	var error = 0;
        var errorusr=0;
	var user = $('#tech_support_username').val();
	if (user === "") {
		$('#tech_support_username').addClass('error');
		errorusr = 1;
	}
	else {
		$('#tech_support_username').removeClass('error');
	}

	var path = $('#tech_support_path').val();
	if (path === "") {
		$('#tech_support_path').addClass('error');
		error = 1;
	}
	else {
		$('#tech_support_path').removeClass('error');
	}
        var bug = $('#tech_support_bugid').val();
        if (bug === "") {
                $('#tech_support_bugid').addClass('error');
                var error1 = 1;
        }
        else {
                $('#tech_support_bugid').removeClass('error');
        }

        var iompath = $('#tech_support_iom').val();
        if (iompath === "") {
                $('#tech_support_iom').addClass('error');
                var error2 = 1;
        }
        else {
                $('#tech_support_iom').removeClass('error');
        }

	if (error == 1 && error1==1)
              {  

                if (error2==1 && errorusr===1 )
               {
                alert("Enter a valid path or bugid");
		return;}
                }
        
	$("#dialog").dialog("close");
	$("#loading").removeClass("hide").addClass('show');
 
         if (path !="" && error2==1)
        {
        $.get(SERVER_LOCATION+CREATE_WS, {user: user, path: path , iompath:iompath , count:"1"}, function(data, status) {


                var data1=data.split("@@")
                var data2=data1[0];

                data3=data1[1];
              
                onWorkspaceCreate(data2,data3,status);
        });
        }

        if (path !="" && error2!=1)
        {
	$.get(SERVER_LOCATION+CREATE_WS, {user: user, path: path , iompath:iompath , count:"1"}, function(data, status) {
	                        
                var data1=data.split("@@")
                var data2=data1[0];
                
                data3=data1[1];
              
		onWorkspaceCreate(data2,data3,status);
	});
        }

        if (path ==="" && error2==1)
        {
        $.get(SERVER_LOCATION+CREATE_WS, {user: user, bug: bug , count:"1"}, function(data, status) {
                var data1=data.split("@@")
                var data2=data1[0];

               
                data3=data1[1];
                onWorkspaceCreate(data2,data3,status);
        });
        }

        if (path ==="" && error2!=1)
        {
        $.get(SERVER_LOCATION+CREATE_WS, {user: user, path: path , iompath:iompath , count:"1"}, function(data, status) {
                var data1=data.split("@@")
                var data2=data1[0];
                data3=data1[1];
                onWorkspaceCreate(data2,data3,status);
        });
        }

       
       if (UPLOADVAR==0){
          path="/ws/sukatara-sjc/"+"myfile";
          $.get(SERVER_LOCATION+CREATE_WS, {user: user, path:path  , iompath:iompath , count:"1"}, function(data, status) {
           var data1=data.split("@@")
                var data2=data1[0];

                data3=data1[1];
              
                onWorkspaceCreate(data2,data3,status);
        });
         }
}

function GetMySuggestionsbug() {
       
        var xhttp1= new XMLHttpRequest();
        
        var bugid=document.getElementById("tech_support_bugid").value;
        
        if (bugid.length >8)
{         
          xhttp1.open("get",SERVER_LOCATION +GET_SUGGESTIONSBUG+"?bugid="+bugid,true);
          xhttp1.send();
          xhttp1.onreadystatechange=function(){
          if(xhttp1.readyState==4 && xhttp1.status==200){
            data=xhttp1.responseText;
            

            data= data.replace("[", '');
	    data=data.replace("]",'');
   	    data=data.split(",");
            
            element=$("#underInput");
            for(var i=0;i<data.length;i++)
{           data[i]=data[i].replace(" ","");
            data[i]=data[i].replace("'","");
            data[i]=data[i].replace("'","");
            key=element.attr('underInput') + '_' + i;
            var values='<div id="' +  + '" class="list_item" onclick="onWorkspaceCreate(data[i] ,"0", \'success\');" title="' + data[i]+ '">' + data[i] + '</div>';
            element.append(values);
}


           }
}
}
}

function GetMySuggestions() {
	var xhttp = new XMLHttpRequest();
	var username=document.getElementById("tech_support_username").value;
	xhttp.open("get", SERVER_LOCATION + GET_SUGGESTIONS + "?username=" + username, true);
	xhttp.send();
        
	var res=[];
	var rest=[];
	var data2;
	xhttp.onreadystatechange = function() {
		data1=null;
                
   
		if (xhttp.readyState==4 && xhttp.status==200) {
                        
			data1=xhttp.responseText;
			data1= data1.replace("[", '');
			data1=data1.replace("]",'');
			data1=data1.split(",");
                         
			for (var k =0; k <data1.length;k++) {
				data2= data1[k].split("path-");
				res[k]=data2[1];
				rest[k]=data2[0];
			}
			element=$("#underInput");
			var data4=" ";
			for (var i=0;i<res.length;i++) {
				data3=res[i].split("/");
				var leng=data3.length;
				data4= data3[leng-1];
				res[i]=res[i].replace("'","");
				rest[i]=rest[i].replace("_","");
				rest[i]=rest[i].replace("'","");
				data4=data4.replace("'","");
				data4=String(rest[i])+"/"+String(data4);
				data4=data4.split(".tar")[0];
				data4=data4+"/"
				data4=data4.replace(" ","");
				var key = element.attr('underInput') + '_' + i;
				var su="success";
				var values = '<div id="' + key + '" class="list_item" onclick="onWorkspaceCreate(\''+data4+'\' ,"0", \'success\');" title="' + res[i] + '">' + res[i] + 
'</div>';
				element.append(values);
			}
		}
	}
}

function getInventory() {
	$.get(SERVER_LOCATION+GET_INVENTORY, {id: CLIENT_ID,count:"1"}, function(data, status) {
		addTab("INVENTORY", data);
		acc=document.getElementsByClassName("accordion");
		var i;
		for (i = 0; i <=acc.length; i++) {
			acc[i].onclick=function() {
				this.classList.toggle("active");
				this.nextElementSibling.classList.toggle("show");
			}
		}
	});
}

// Date Time Picker
$(function() {
	$('#date_from').datetimepicker({
		format:'Y/m/d',
		onShow:function(ct){
			this.setOptions({
				maxDate:$('#date_to').val()?$('#date_to').val():false
			});
		},
		onClose:validateTime,
		timepicker:false
	});
	$('#date_to').datetimepicker({
		format:'Y/m/d',
		onShow:function(ct){
			this.setOptions({
				minDate:$('#date_from').val()?$('#date_from').val():false
			});
		},
		onClose:validateTime,
		timepicker:false
	});
	$('#time_from').datetimepicker({
		format:'H:i:s',
		onClose:validateTime,
		datepicker:false,
		step:10
	});
	$('#time_to').datetimepicker({
		format:'H:i:s',
		onClose:validateTime,
		datepicker:false
	});
});

// Validates To and From time. From should be before To.
function validateTime(ct) {
	var t_from = $('#time_from').val();
	var t_to = $('#time_to').val();
	var d_from = $('#date_from').val();
	var d_to = $('#date_to').val();

	if (typeof t_from == 'undefined') return;
	if (typeof t_to == 'undefined') return;
	if (typeof d_from == 'undefined') return;
	if (typeof d_to == 'undefined') return;
	if (t_from === '') return;
	if (t_to === '') return;
	if (d_from === '') return;
	if (d_to === '') return;

	var d1 = new Date(d_from + " " + t_from);
	var d2 = new Date(d_to + " " + t_to);

	if (isNaN(d1.getTime())) return;
	if (isNaN(d2.getTime())) return;

	if (d1.getTime() > d2.getTime())  {
		alert("Invalid Time Range: 'From' should be before 'To'");
		$('.datetime').addClass('error');
	} else {
		$('.datetime').removeClass('error');
	}
}

function windowResize() {
	// $('#debug').text("Width: " + $(window).width() + "px, Height: " + $(window).height());

	// For IE
	var extra_padding_for_ie = 0;
	//alert(window.navigator.userAgent);
	if (window.navigator.userAgent.indexOf("MSIE ") > 0) {
		extra_padding_for_ie = 15;
	}

	// Calculate width of right panels
	var padding = 60;
	var remaining = $(window).width() - $('#top_left').width() - padding;
	$('#top_right').css('width', remaining-extra_padding_for_ie + 'px');
	$('#bottom_right').css('width', remaining + 'px');
	var left =  $('#bottom_left').width() + $('#bottom_right').width() + 52;

	// Calculate height of bottom panels
	remaining = $(window).height() - $('#top_left').height() - padding - extra_padding_for_ie;
	$('#bottom_left').css('height', remaining + 'px');
	$('#bottom_right').css('height', remaining + 'px');
	$('.tab_content').css('height', remaining-35 + 'px');

	// Resize Search Bar
	var width=$('#top_right').width();
	$('#search_text').css('width', width-35 + 'px');
}

// actual addTab function: adds new tab using the input from the form above
function addTab(title, content) {

	var label = title || "Tab " + tabCounter;
        var id = "tabs-" + tabCounter;
        var li = $(tabTemplate.replace(/#\{href\}/g, "#" + id).replace(/#\{label\}/g, label).replace(/#\{title\}/g, title));
	
	tabs_content[id] = content;
	tabs.find(".ui-tabs-nav").append(li);
	tabs.append("<div id='" + id + "' class='tab_content'><p></p></div>");
	tabs.tabs("refresh");
	$("#tabs").tabs("option", "active", tab_count);
	tabCounter++;
	tab_count++;
	windowResize();
	
}

// Toggle Show/Hide for bottom left column's COMMANDS and FILES
function toggle_show_hide(elem, list) {
        
	if (typeof elem == 'undefined'){ return;}
	if (typeof list == 'undefined'){ return;}
       
	if ($(list).hasClass('hide')) {
		// Show
		$(list).removeClass("hide").addClass("show");
		var text = $(elem).text();
		text = text.replace("\+", "-");
		$(elem).text(text);         
	}
 
	else if ($(list).hasClass('show')) {
		// Hide
		$(list).removeClass("show").addClass("hide");
		var text = $(elem).text();
		text = text.replace("-", "+");
		$(elem).text(text);
		document.getElementById("loading").removeClass("show").addclass("hide");
                
	}

}

function toggle_show_hide1(elem, list) {
        

        if (typeof elem == 'undefined'){ return;}
        if (typeof list == 'undefined'){ return;}

        if ($(list).hasClass('hide')) {
                // Show
                $(list).removeClass("hide").addClass("show");
                var text = $(elem).text();
                text = text.replace("\+", "-");
                $(elem).text(text);
                
        }

        else if ($(list).hasClass('show')) {
                // Hide
                $(list).removeClass("show").addClass("hide");
                var text = $(elem).text();
                text = text.replace("-", "+");
                $(elem).text(text);
                document.getElementById("loading").removeClass("show").addclass("hide");
                
        }

}

        


function parse_brief(side,data,status) {
	if (status !== "success") {
		console.log("GET for parse_commands for side: " + side + " did not return success, status: " + status);
		return;
	}
	if (typeof data == 'undefined') {
		console.log("commands data undefined for side: " + side);
		return;
	}
	if (data === null)  {
		console.log("commands data null for side: " + side);
		return;
	}

	if (side === "A") {
		a_brief_list = data.split("\n");
		command_add(a_brief_list, $('#a_briefs_list'));
	} else if (side === "B") {
		b_brief_list = data.split("\n");
		command_add(b_brief_list, $('#b_briefs_list'));
	}
}



function parse_iomcommands(side, data, status) {
        if (status !== "success") {
                console.log("GET for parse_commands for side: " + side + " did not return success, status: " + status);
                return;
        }
        if (typeof data == 'undefined') {
                console.log("commands data undefined for side: " + side);
                return;
        }
        if (data === null) {
                console.log("commands data null for side: " + side);
                return;
        }

        if (side === "A") {
                a_iom_lists = data.split("\n");
                command_add(a_iom_lists, $('#a_iom_list'));
        } else if (side === "B") {
                b_iom_lists = data.split("\n");
                command_add(b_iom_lists, $('#b_iom_list'));
        }
}
//IOM files parsing
function parse_iomfiles(data, status){
	if (status !== "success") { 
		console.log("GET for parse_iomfiles did not return success, status: " + status); 
		return;
 	}
 	if (typeof data == 'undefined') {
 		console.log("files data undefined ");
 		return; 
	} 
	if (data === null)  {
 		console.log("files data null"); 
		return; 
	} 
		
 		iom_file_list = data.split("\n");
 		command_addx(iom_file_list, $('#iom_files_list'));
		 
}

function parse_commands(side, data, status) {
	if (status !== "success") {
		console.log("GET for parse_commands for side: " + side + " did not return success, status: " + status);
		return;
	}
	if (typeof data == 'undefined') {
		console.log("commands data undefined for side: " + side);
		return;
	}
	if (data === null) {
		console.log("commands data null for side: " + side);
		return;
	}

	if (side === "A") {
		a_command_list = data.split("\n");
		command_add(a_command_list, $('#a_commands_list'));
	} else if (side === "B") {
		b_command_list = data.split("\n");
		command_add(b_command_list, $('#b_commands_list'));
	}
}

function parse_files(side, data, status) {
	if (status !== "success") {
		console.log("GET for parse_files for side: " + side + " did not return success, status: " + status);
		return;
	}
	if (typeof data == 'undefined') {
		console.log("files data undefined for side: " + side);
		return;
	}
	if (data === null)  {
		console.log("files data null for side: " + side);
		return;
	}

	if (side === "A") {
		a_file_list = data.split("\n");
		command_add(a_file_list, $('#a_files_list'));
	} else if (side === "B") {
		b_file_list = data.split("\n");
		command_add(b_file_list, $('#b_files_list'));
	}
}

//all files listing
function new_parse_files(side, data, status) {
        if (status !== "success") {
                console.log("GET for parse_files for side: " + side + " did not return success, status: " + status);
                return;
        }
        if (typeof data == 'undefined') {
                console.log("files data undefined for side: " + side);
                return;
        }
        if (data === null)  {
                console.log("files data null for side: " + side);
                return;
        }

        if (side === "A") {
                a_file_list_new = data.split("\n");
                command_add(a_file_list_new, $('#a_files_list_new'));
        } else if (side === "B") {
                b_file_list_new = data.split("\n");
                command_add(b_file_list_new, $('#b_files_list_new'));
        }
}



function command_search() {
	if (a_command_list !== "")
		command_add1(a_command_list, $('#a_commands_list'));
	if (a_file_list !== "")
		command_add1(a_file_list, $('#a_files_list'));
	if (b_command_list !== "")
		command_add1(b_command_list, $('#b_commands_list'));
	if (b_file_list !== "")
		command_add1(b_file_list, $('#b_files_list'));
	if (a_iom_lists !== "")
		command_add1(a_iom_lists, $('#a_iom_list'));
	if (b_iom_lists !== "")
		command_add1(b_iom_lists, $('#b_iom_list'));
        if (a_file_list_new !== "")
                command_add1(a_file_list_new, $('#a_files_list_new'));
        if (b_file_list_new !== "")
                command_add1(b_file_list_new, $('#b_files_list_new'));

}

// Searches search_term in list and saves it to the element
function command_add(list, element) {
        
	var search_term = $('#command_search_text').val();
	element.empty();
	var count=0;
	for (var i=0;i<list.length;i++) {
		var key = element.attr('id') + '_' + i;
		var result = list[i].search(new RegExp(search_term, "i"));
		if (result != -1) {
			var values = '<div id="' + key + '" class="list_item" onclick="commands_get_content(this);" title="' + list[i] + '">' + list[i] + '</div>';
			element.append(values);
			count++;
		}
	}
 
}

//for iom files.  onclick will be untaring the file then show the content

function command_addx(list, element){
	var search_term = $('#command_search_text').val();
	element.empty();
	var count = 0;
	for(var i =0; i<list.length-1;i++){
        		
		var key = element.attr('id')+ '_' +i;
		
		var result = list[i].search(new RegExp(search_term, "i"));
		if(result != -1){
		      var values = '<div class = "collapsible_items"><div id="'+key+'" class="list_item" onclick = "untarfunction(this,'+i+'); toggle_check1(this, iom_files_list_'+i+',new_data_iom_'+i+', new_sys_file_iom_'+i+'); toggle_check(this,new_data_iom_'+i+', new_sys_file_iom_'+i+'); toggle_show_hide_new(this, new_data_iom_'+i+',iomdebugdump_'+i+', iomvnic_'+i+'); "  title="' + list[i] + '">'+"  [ + ]" +list[i]+'</div><div class = "collapsible_items"><div id = "new_data_iom_'+i+'" class = "hide" onclick ="tryfunction(this,'+i+'); toggle_show_hide(this, new_sys_file_iom_'+i+');" title="'+list[i]+'"></div><div id = "new_sys_file_iom_'+i+'" class = "hide"></div></div><div class = "collapsible_items"><div id = "iomdebugdump_'+i+'" class = "hide" onclick="commands_get_content(this);" title = "'+list[i]+'">debugdump</div></div><div id = "iomvnic_'+i+'" class = "hide" onclick= "commands_get_content(this);" title = "'+list[i]+'">vnic.cfg</div></div>';
		
			element.append(values);
			count++;
		}
	}
	
}

function toggle_show_hide_new(elem, list1, list2, list3) {
        if (typeof elem == 'undefined'){ return;}
        if (typeof list1 == 'undefined'){ return;}
	
        if ($(list1).hasClass('hide')) {
                // Show

                $(list1).removeClass("hide").addClass("show");
                $(list2).removeClass("hide").addClass("show");
                $(list3).removeClass("hide").addClass("show");

                var text = $(elem).text();
                text = text.replace("\+", "-");
                $(elem).text(text);

        }

        else if ($(list1).hasClass('show')) {
                // Hide
                
                $(list1).removeClass("show").addClass("hide");
                $(list2).removeClass("show").addClass("hide");
                $(list3).removeClass("show").addClass("hide");

                var text = $(elem).text();
                text = text.replace("-", "+");
                $(elem).text(text);
                document.getElementById("loading").removeClass("show").addclass("hide");

        }
}


function toggle_check(elem, list1, list){
        if (typeof elem == 'undefined'){ return;}
        if (typeof list == 'undefined'){ return;}
	
        if ($(list1).hasClass('show') && $(list).hasClass('show')) {
                // Hide
                $(list).removeClass("show").addClass("hide");
                var text = $(elem).text();
                $(elem).text(text);
        }
}

function toggle_check1(elem, list1, list, list2){
	if (typeof elem == 'undefined'){return;}
        if (typeof list == 'undefined'){ return;}

        if ($(list1).hasClass('show') && $(list).hasClass('show')) {
                // Hide
                $(list).removeClass("show").addClass("hide");
                var text = $(elem).text();
                text = text.replace("-", "+");
                $(elem).text(text);	
        }
	if ($(list2).hasClass('show')) $(list2).removeClass("show").addClass("hide");
}

function tryfunction(element,i){
	var id = $(element).attr('id');
	var mez = $(element).attr('title').split(".")[0];
	var title = file_item[0];
	
	$.get(SERVER_LOCATION+IOM_UNTAR_INNER, {id: IOM_ID, mez: mez_value, path: title}, function(data, status){
		iom_filedata(data, status,i);
	});	
}

function iom_filedata(data, status,i){
	
	sys_log_list = data.split("\n");	
	command_add(sys_log_list, $('#new_sys_file_iom_'+i));
}

//untar IOM files
function untarfunction(element,i){
	//utar the file
	
	var id = $(element).attr('id');
	var title = $(element).attr('title');
	mez_value = title.split(".")[0];
	
	$.get(SERVER_LOCATION+IOM_UNTAR, {id: IOM_ID, path: title}, function(data, status){
		iom_filenames(data, status,id,i);
	});
}

//After untar, show the contents
function iom_filenames(data, status,data_item,i){
	

        if (status !== "success") {
                console.log("GET for parse_iomfiles did not return success, status: " + status);
                return;
        }
        if (typeof data == 'undefined') {
                console.log("files data undefined ");
                return;
        }
        if (data === null)  {
                console.log("files data null");
                return;
        }
	
        file_item = data.split("\n");
	command_addy(file_item, $('#new_data_iom_'+i));

}

function command_add1(list, element) {
        var search_term = $('#command_search_text').val();
        element.empty();
        var count=0;
        for (var i=0;i<list.length;i++) {
                var key = element.attr('id') + '_' + i;
                var result = list[i].search(new RegExp(search_term, "i"));
                if (result != -1) {
                        var values = '<div id="' + key + '" class="list_item" onclick="commands_get_content(this);" title="' + list[i] + '">' + list[i] + '</div>';
                        element.append(values);
                        count++;
                }
        }
}

//Untar inner files of IOM
function command_addy(list, element) {

        var search_term = $('#command_search_text').val();
        element.empty();
        var count=0;
        for (var i=0;i<list.length;i++) {
                var key = element.attr('id') + '_' + i;
		key1 = key;
		
                var result = list[i].search(new RegExp(search_term, "i"));
                if (result != -1) {
                        var values = '<div id="' + key + '" class="list_item"  title="' + list[i] + '">' + list[i] + '</div>';
                        element.append(values);
                        count++;
                }
        }

}

var temp;
var myworker= new Array;

// TODO: Get command details from cached copy
function commands_get_content(element,key) {
	var id = $(element).attr('id');
        var filter=0;
	var side = id.charAt(0) + "";
	var type = "";
	if( (id.indexOf("commands") > -1) || (id.indexOf("briefs")>-1)) 
        {
		type = "command";
	}
	else if ( id.indexOf("iom") >-1)  
	{	type = "command";
		
	}
        else {
         type="file";
        }
	
	var text = $(element).text();
	var page=0;
        substring = "iom";
        if(id.indexOf(substring) == -1){
              var filter=1
        }
	if((id.indexOf("iom")>-1) &&(id.indexOf("file")>-1) ){
		type = "file";
	}
	if ((id.indexOf('iomdebugdump'))>-1 || (id.indexOf('iomvnic'))>-1)
		type = "file";

	get_web_worker(page);
	
	function get_web_worker(page) {
		myworker[page]=new Worker("scripts/getcontents.js");
                if (filter==1){
		myworker[page].postMessage({ id:CLIENT_ID, side:side, type:type, text:text, page:page,filter:filter });
                }
                else{
                myworker[page].postMessage({ id:IOM_ID, side:side, type:type, text:text, page:page,filter:filter, mez_value:mez_value });
		}
                myworker[page].onmessage=function(event) {
			temp=event.data;
			var temp1;
			temp1= parseInt(temp1);
			var len = temp.length;
			
			if(temp[len-3]!= " ")
				var pages = parseInt(temp[len-3])*10 + parseInt(temp[len-2]);
			else var pages = parseInt(temp[len-2]);

			pages = pages-1;
			temp1 = pages;	
			//adding new tabs
			if(type == "file" && filter == 0)	//IOM_files
				addTab(mez_value+"|"+text+"|"+(parseInt(page)+1), temp);
			else if(type =="file")
				addTab(side.toUpperCase() + " | " +text+"|"+(parseInt(page)+1), temp);
			else
				addTab(side.toUpperCase()+" | "+text, temp)
		
			if (type=="command") {
				acc= document.getElementsByClassName("accordion");
				
				var i;
				for(i=0; i <=acc.length ; i ++) {
					acc[i].onclick=function() {
						this.classList.toggle("active");
						this.nextElementSibling.classList.toggle("show");
					}
				}
			} else if (type=="file") {
				for (var i=0;i<=temp1;i++) {
					var but= document.createElement("button");
					var t = document.createTextNode(i+1);
					but.setAttribute("id",i);
					but.appendChild(t,id);
					var temp2=tabCounter-1;
                                        document.getElementById("tabs-"+temp2).appendChild(but);

					but.onclick=function(){ get_web_worker(this.id);}
				}
			}
		}
	}
}


// Input date and time
// Returns time converted to Milliseconds from January 1, 1970
// Returns 0, if date and time is not specified
// Returns 0, if only time is specified
function getMilliseconds(date, time) {
	if (date === null) return 0;
	if (date === "") return 0;

	if (time === null) time = "";

	var d = new Date(date + " " + time);
	return d.getTime();
}

// Parse tab data and highlight search results
function parse_tab_data(data) {
	if (typeof data == 'undefined') return;
	if (data === null) return;
	if (data === '') return;

	// Get user added date_from, time_from. Convert it to unix time format
	var from_millis = getMilliseconds($('#date_from').val(), $('#time_from').val());

	// Get user added date_to, time_to. Convert it to unix time format
	var time_to = $('#time_to').val();
	if (time_to === "") {
		// If time_to is not specified, default should be considered as "23:59:59"
		time_to = "23:59:59";
	}
	var to_millis = getMilliseconds($('#date_to').val(), time_to);

	// Parse Time
	var data_split = data.split("\n");
	data_split_length = data_split.length;

	data = "";

	 // Default is show this line.
	var show = 1;
	for (i=0; i<data_split_length; i++) {
		// Parse 'Jan 5 08:23:07 2015'

		var match = data_split[i].match(RE_TIME);
		if (match !== null) {
			var current_date = new Date(match[0]);
			var current_date_millis = current_date.getTime();
			if (isNaN(current_date_millis)) {
				// Something wrong in date regex. Should not hit here.
				//alert("BUG: Something wrong in date regex. Should not hit here. Match: " + match);
			}
			if ((to_millis != 0) && (from_millis != 0)) {
				if ((current_date_millis >= from_millis) && (current_date_millis <= to_millis)) {
					show = 1;
				}
				else {
					show = 0;
				}
			}
			else if (to_millis == 0) {
				if (current_date_millis >= from_millis) {
					show = 1;
				}
				else {
					show = 0;
				}
			}
			else if (from_millis == 0) {
				if (current_date_millis <= to_millis) {
					show = 1;
				}
				else {
					show = 0;
				}
			}
		}

		// Convert data_split[] back to data
		if (show === 1) {
			if (match === null) {
				data += data_split[i] + "\n";
			} else {
				data += data_split[i].replace(match[0], "<span class='time'>" + match[0] + "</span>") + "\n";
			}
		}
	}

	// Empty data_split to free up some RAM
	data_split = [];

	var active_tab_id = $(".ui-state-active").attr("aria-controls");

	// Highlight all search terms
	for (i=0;i<search_terms.length;i++) {
		data = data.replace(
			new RegExp(search_terms[i]['term'], 'gi'),
			function($0, $1, $2){
				return "<span tabindex='0' class='highlighted_text_" + active_tab_id + "' id='highlighted_text_" + i + "' style='color:"
					+ search_terms[i]['fgcolor']
					+ ";background-color:" + search_terms[i]['bgcolor'] + ";'>"
					+ $0
					+ "</span>";
			});
	}

	// Open Files in OpenGroc
	data = data.replace(
		new RegExp('(\\w)+\\.c', 'gi'),
		function($0, $1, $2){
			return "<a target='_blank' href='" + OPENGROC_SERVER + BRANCH + "/search?path=" +$0 + "'>" + $0 + "</a>";
		});

	return '<pre>' + data  + '</pre>';

}

// Add search_terms
function add_to_search_terms(term) {
	if ((term === null) || (term === ""))
		return FAILURE;

	term = term.trim();
	var search_terms_length = search_terms.length;

	// If exists, do not add. (Cause confusion with color)
	for (i=0; i<search_terms_length; i++) {
		if (search_terms[i]['term'] === term)
			return FAILURE;
	}

	search_terms.push({
		term:term,
		bgcolor:search_terms_color[search_terms_color_count][0],
		fgcolor:search_terms_color[search_terms_color_count][1]
	});
	search_terms_color_count = (search_terms_color_count + 1) % search_terms_color.length;
	update_search_terms_ui();

	// Update content of active tab
	tabs_updated = [];	// Reset list of updated tabs.
	update_active_tab();

	return SUCCESS;
}

// Update the tab contents. This is useful if new search_terms are added.
function update_active_tab() {
	var active_tab_id = $(".ui-state-active").attr("aria-controls");

	if ($.inArray(active_tab_id, tabs_updated) != -1) {
		// Tab is already updated, no need to parse
		return;
	}
	tabs_updated.push(active_tab_id);

	$('#'+active_tab_id).html(parse_tab_data(tabs_content[active_tab_id]));
}

// Remove remove_term from search_terms
function remove_from_search_terms(remove_term) {
	if (remove_term >= search_terms.length) {
		return;
	}

	search_terms.splice(remove_term, 1);
	update_search_terms_ui();

	// Update content of active tab
	tabs_updated = [];	// Reset list of updated tabs.
	update_active_tab();
}

// After search_term is added/removed, we need to update the UI
function update_search_terms_ui() {
	var text = "";
	for (i=0; i<search_terms.length; i++) {
		text += "<div class='search_term' style='color:" + search_terms[i]['fgcolor'] + ";background-color:" + search_terms[i]['bgcolor'] + ";'>";
		text += "<span class='search_term_l'>" + search_terms[i]['term'] + "</span>";
		text += "<span class='search_term_r' onclick='remove_from_search_terms(\"" + i + "\");'>X</span>";
		text += "</div>";
	}
	text += '<div class="clear"></div>';
	$('#search_terms').html(text);
}

// Shows Inventory in the top_left container
function show_inventory(data) {
	data = data.replace(new RegExp('\n', 'gi'), '<br />');
	$('#top_left').html(data);
}

// Workspace is created on server. Show Next Screen.
function onWorkspaceCreate(data,data3,status) {

	$("#dialog").hide();

	document.getElementById('dialog').parentNode.style.display='none';
	$("#ui-id-1").hide();

	if(data== "error\n") {
		alert("Path does not exists");
		$("#dialog").dialog("open");
		$("#loading").removeClass("show").addClass('hide');
		return;
	}
	
	
	data=data+"/";
        data3=data3+"/";
	
	if (status !== "success") {
		alert('Something went wrong. Please try again later.\nStatus: ' + status);
		$("#dialog").dialog("open");
		$("#loading").removeClass("show").addClass('hide');
		return;
	}
	if (typeof data == 'undefined') {
		alert('Something went wrong. Please try again later1');
		$("#dialog").dialog("open");
		$("#loading").removeClass("show").addClass('hide');
		return;
	}
	if ((data === null) || (data === "")) {
		alert('Something went wrong. Please try again later. No data received.');
		$("#dialog").dialog("open");
		$("#loading").removeClass("show").addClass('hide');
		return;
	}
	

	$("#loading").removeClass("show").addClass('hide');
	
	
	// Server returns 'error' if file does not exist.
	if ((data === "error\n") || data.indexOf("error")>-1) {
		
		$('#tech_support_username').removeClass('error');
		$('#tech_support_path').addClass('error');
                $('#tech_support_iom').addClass('error');
		alert('Either file does not exist or the path is unreachable: ' + $('#tech_support_path').val());
		$("#dialog").dialog("open");
		//console.log("refreshing");
		//location.reload();
		return;
	}

	// Set CLIENT_ID
 	CLIENT_ID = data.replace("\n","");
        
 	// Run All Get Commands for .containers
	// Get Inventory
        IOM_ID=data3.replace("\n","");
	$.get(SERVER_LOCATION+INVENTORY, {side: "A", id: CLIENT_ID, count:"1"}, function(data, status) {
              
		show_inventory(data);
	});
	$.get(SERVER_LOCATION+BRIEF, {side: "A", id: CLIENT_ID}, function(data,status) {
             
	     parse_brief("A", data, status);
	});
	$.get(SERVER_LOCATION+BRIEF, {side: "B", id: CLIENT_ID}, function(data,status){
		parse_brief("B", data, status);
	});

	// Get Commands
	$.get(SERVER_LOCATION+COMMANDS, {side: "A", id: CLIENT_ID}, function(data, status) {
		parse_commands("A", data, status);
	});
	$.get(SERVER_LOCATION+COMMANDS, {side: "B", id: CLIENT_ID}, function(data, status) {
		parse_commands("B", data, status);
	});

	// Get Files
        $.get(SERVER_LOCATION+NEWFILES, {side: "A", id: CLIENT_ID}, function(data, status) {
               new_parse_files("A", data, status);
        });

	$.get(SERVER_LOCATION+NEWFILES, {side: "B", id: CLIENT_ID}, function(data, status) {
               new_parse_files("B", data, status);              
        });
       
         // Get IOM Commands
        $.get(SERVER_LOCATION+IOMCOMMANDS, {side: "A", id: IOM_ID}, function(data, status) {
                
                parse_iomcommands("A", data, status);
        });
        $.get(SERVER_LOCATION+IOMCOMMANDS, {side: "B", id: IOM_ID}, function(data, status) {
                parse_iomcommands("B", data, status);
        });

	// Get IOM Files
	$.get(SERVER_LOCATION+IOMFILES, {id: IOM_ID}, function(data, status){
		parse_iomfiles(data, status);
	});

	$.get(SERVER_LOCATION+VETH_LISTING, {id: CLIENT_ID}, function(data,status){
		list_veth(data, status);
	});


	// Unhide all .contain
	$(".container").removeClass('hide').addClass('show');
}
//veth
function list_veth(data, status){

	if (status !== "success") {
                console.log("GET for list_veth did not return success, status: " + status);
                return;
        }
        if (typeof data == 'undefined') {
                console.log("files data undefined ");
                return;
        }
        if (data === null)  {
                console.log("files data null");
                return;
        }
                
                
                veth_lists = data.split("\n");
                command_addv(veth_lists, $('#veth_list'));
}


function command_addv(list, element) {

        var search_term = $('#command_search_text').val();
        element.empty();
        var count=0;
        for (var i=0;i<list.length;i++) {
                var key = element.attr('id') + '_' + i;
                var result = list[i].search(new RegExp(search_term, "i"));
                if (result != -1) {
                          var values = '<div id="' + key + '" class="list_item" onclick="get_veth_data(this);" title="' + list[i] + '">' + list[i] + '</div>';
                        element.append(values);
                        count++;
                }
        }
 
}


// Loop through search_terms results when 'N'(next) or 'P'(previous) is pressed on keyboard
$(function() {
	// Class: highlighted_text
	// ID: highlighted_text_i
	$('body').keydown(function (e) {
		// 'N'
		if (e.which === 78) {
			var active_tab_id = $(".ui-state-active").attr("aria-controls");
			var index = $('.highlighted_text_' + active_tab_id).index($(':focus')) + 1;
			$('.highlighted_text_'+active_tab_id).eq(index).focus();
		}
		// 'P'
		else if (e.which === 80) {
			var active_tab_id = $(".ui-state-active").attr("aria-controls");
			var index = $('.highlighted_text' + active_tab_id).index($(':focus')) - 1;
			$('.highlighted_text_'+active_tab_id).eq(index).focus();
		}
		// '['
		else if (e.which === 219) {
			var active = $( "#tabs" ).tabs( "option", "active" );
			if (active == 0)
				return;
			$( "#tabs" ).tabs( "option", "active", active - 1 );
			tabs.tabs("refresh");
		}
		// ']'
		else if (e.which === 221) {
			var active = $( "#tabs" ).tabs( "option", "active" );
			//if (active == 0)
			//	return;
			$( "#tabs" ).tabs( "option", "active", active + 1 );
			tabs.tabs("refresh");
		}
	});
});

//Get Veth Data (new)
function get_veth_data(element){
	var title = $(element).attr('title');
	//
	$.get(SERVER_LOCATION+VETH_DATA, {id: CLIENT_ID, id2: IOM_ID, title: title, count:"1"}, function(data, status) {
		//addTab(title, data);
		if (IOM_ID === "/")
			alert('Some features will not work as expected as no IOM tech-support is provided.');
		if (title.indexOf('A')>-1)
			addTab('A|'+title.split('-')[0],data);
		else if (title.indexOf('B')>-1)
			addTab('B|'+title.split('-')[0],data);
		acc= document.getElementsByClassName("accordion");
                	var i;
                        for(i=0; i <=acc.length ; i ++) {
                        	acc[i].onclick=function() {
                                	this.classList.toggle("active");
                                        this.nextElementSibling.classList.toggle("show");
                                }
                         }
	});
	
}
//new_end

// Get System Health
function get_system_health() {
	$.get(SERVER_LOCATION+SYSTEM_HEALTH, {id: CLIENT_ID,count:"1"}, function(data, status) {
		addTab("System Health", data);
	});
}
function getscaling(){
	$.get(SERVER_LOCATION+GET_SCALING, { id:CLIENT_ID,count:"1"} , function(data,status) {
		addTab("Scaling", data);
	});
}
function getintdiff(){
        
        client_id=client_id.trim("\n");
	if (client_id === "")
		alert('Need one more tech support file');
	else{
        $.get(SERVER_LOCATION+DIFF, { id:CLIENT_ID,id1:client_id,count:"1"} , function(data,status) {
                addTab("INTERFACES DIFFERENCE", data);
        }); 
	}
}

